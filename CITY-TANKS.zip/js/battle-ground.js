// Both the mesh and the simulation use the same two triangles per cell. Horizontal
// coordinates and returned heights are CITY TANKS world units (nine per metre).
class BattleGround {
  constructor(arena) {
    this.W = arena.bounds.x;
    this.H = arena.bounds.y;
    const m = BATTLE_UNITS_PER_METRE,
      hills = {
        field: [10, 0.016, 0.018],
        desert: [16, 0.014, 0.011],
        quarry: [14, 0.012, 0.016],
        frost: [8, 0.014, 0.018]
      }[arena.id];
    this.cols = hills || arena.water.length ? Math.ceil((this.W * 2) / (8 * m)) : 1;
    this.rows = hills || arena.water.length ? Math.ceil((this.H * 2) / (8 * m)) : 1;
    this.dx = (2 * this.W) / this.cols;
    this.dy = (2 * this.H) / this.rows;
    this.samples = new Float32Array((this.cols + 1) * (this.rows + 1));
    this.min = this.max = 0;
    if (!hills && !arena.water.length) return;
    // Keep foundations, training lane and shoreline level. Limit the grade out
    // of each apron rather than dropping the adjacent terrain vertically.
    const margin = Math.hypot(this.dx, this.dy),
      pads = [...arena.walls, ...arena.water, { x: -34 * m, y: -12 * m, w: 68 * m, h: 24 * m }];
    for (let j = 0; j <= this.rows; j++)
      for (let i = 0; i <= this.cols; i++) {
        const x = i * this.dx - this.W,
          y = j * this.dy - this.H,
          X = x / m,
          Y = y / m;
        let h = 0;
        if (hills) {
          const [amp, fx, fy] = hills;
          const ridge =
            0.48 +
            0.22 * Math.cos(X * fx + Y * fy) +
            0.19 * Math.cos(X * fx * 0.64 - Y * fy * 1.4) +
            0.11 * Math.cos(Y * fy * 1.8);
          let room = Math.min(this.W - Math.abs(x), this.H - Math.abs(y));
          for (const r of pads) {
            const d = Math.max(r.x - x, x - r.x - r.w, r.y - y, y - r.y - r.h, 0);
            if (d < room) room = d;
            if (room <= margin) break;
          }
          h = Math.max(0, Math.min(amp * m * ridge, (room - margin) * 0.15));
        }
        // Shallow bank, then a submerged bed. Bridges/ice crossings aren't water.
        for (const r of arena.water) {
          const inset = Math.min(x - r.x, r.x + r.w - x, y - r.y, r.y + r.h - y);
          if (inset > 0) h = -Math.min(3.6 * m, inset * 0.235);
        }
        this.samples[i + j * (this.cols + 1)] = h;
        this.min = Math.min(this.min, h);
        this.max = Math.max(this.max, h);
      }
  }
  value(k, u, v) {
    const a = this.samples,
      n = this.cols + 1;
    return u + v <= 1
      ? a[k] + u * (a[k + 1] - a[k]) + v * (a[k + n] - a[k])
      : a[k + n + 1] + (1 - u) * (a[k + n] - a[k + n + 1]) + (1 - v) * (a[k + 1] - a[k + n + 1]);
  }
  at(x, y) {
    if (this.min === this.max || Math.abs(x) >= this.W || Math.abs(y) >= this.H) return 0;
    const u = (x + this.W) / this.dx,
      v = (y + this.H) / this.dy,
      i = Math.min(this.cols - 1, Math.floor(u)),
      j = Math.min(this.rows - 1, Math.floor(v));
    return this.value(i + j * (this.cols + 1), u - i, v - j);
  }
  // First intersection of a finite ray with the heightfield. Walk only crossed
  // cells and split at each diagonal, so even a grazing ray cannot skip a ridge.
  ray(x, y, h, dx, dy, dh, limit) {
    const plane = dh < 0 ? -h / dh : Infinity;
    if (this.min === this.max) return plane >= 0 && plane <= limit ? plane : Infinity;
    if (h > this.max && h + dh * limit > this.max) return Infinity;
    let lo = 0,
      hi = limit;
    for (const [o, d, half] of [
      [x, dx, this.W],
      [y, dy, this.H]
    ]) {
      if (Math.abs(d) < 1e-12) {
        if (Math.abs(o) > half) return plane >= 0 && plane <= limit ? plane : Infinity;
      } else {
        const a = (-half - o) / d,
          b = (half - o) / d;
        lo = Math.max(lo, Math.min(a, b));
        hi = Math.min(hi, Math.max(a, b));
      }
    }
    if (plane >= 0 && plane < lo && plane <= limit) return plane;
    if (dh < 0 && h > this.max) lo = Math.max(lo, (this.max - h) / dh);
    const du = dx / this.dx,
      dv = dy / this.dy,
      u0 = (x + this.W) / this.dx,
      v0 = (y + this.H) / this.dy;
    let i = bounded(Math.floor(u0 + du * lo + (du < 0 ? -1e-9 : 0)), 0, this.cols - 1),
      j = bounded(Math.floor(v0 + dv * lo + (dv < 0 ? -1e-9 : 0)), 0, this.rows - 1);
    let tx = du ? ((du > 0 ? i + 1 : i) - u0) / du : Infinity,
      ty = dv ? ((dv > 0 ? j + 1 : j) - v0) / dv : Infinity;
    while (lo <= hi && i >= 0 && j >= 0 && i < this.cols && j < this.rows) {
      const end = Math.max(lo, Math.min(hi, tx, ty)),
        k = j * (this.cols + 1) + i,
        U = u0 - i,
        V = v0 - j;
      const gap = (t) => h + dh * t - this.value(k, U + du * t, V + dv * t);
      let g = gap(lo),
        start = lo;
      if (g <= 0) return lo;
      const diag = du + dv ? (1 - U - V) / (du + dv) : Infinity;
      if (diag > lo && diag < end) {
        const next = gap(diag);
        if (next <= 0) return lo + ((diag - lo) * g) / (g - next);
        g = next;
        start = diag;
      }
      const last = gap(end);
      if (last <= 0) return start + ((end - start) * g) / (g - last);
      if (end >= hi) break;
      if (tx <= end + 1e-8) {
        i += Math.sign(du);
        tx += Math.abs(1 / du);
      }
      if (ty <= end + 1e-8) {
        j += Math.sign(dv);
        ty += Math.abs(1 / dv);
      }
      lo = end;
    }
    // A zero-height apron exists only OUTSIDE the grid. In particular a ray
    // ending exactly at sea level over a deep bed has not hit the terrain.
    if (
      plane >= 0 &&
      plane <= limit &&
      (Math.abs(x + dx * plane) >= this.W || Math.abs(y + dy * plane) >= this.H)
    )
      return plane;
    return Infinity;
  }
}
