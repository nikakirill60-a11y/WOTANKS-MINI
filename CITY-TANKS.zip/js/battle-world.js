// Procedural scenery: no texture/model downloads. Solid cover and ground markings are
// built from the very same wall and terrain records that the simulation collides with.
function buildBattleWorld(scene, state) {
  const T = THREE,
    city = state.curMap === 'city',
    sand = state.curMap === 'desert';
  const weather = WeatherEngine.currentWeather,
    night = weather === 'night',
    overcast = weather === 'rain' || weather === 'snow';
  let seed = city ? 3709 : sand ? 1199 : 5903;
  const random = () => (seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0) / 4294967296;
  const box = new T.BoxGeometry(),
    cylinder = new T.CylinderGeometry(0.5, 0.5, 1, 12);
  const crown = new T.IcosahedronGeometry(0.5, 0),
    pine = new T.ConeGeometry(0.5, 1, 7);
  const matte = new T.MeshLambertMaterial(),
    batches = new Map(),
    matrix = new T.Object3D();
  function place(shape, x, h, z, w, height, depth, color, turn = 0) {
    matrix.position.set(x, h, z);
    matrix.scale.set(w, height, depth);
    matrix.rotation.set(0, turn, 0);
    matrix.updateMatrix();
    if (!batches.has(shape)) batches.set(shape, []);
    batches.get(shape).push([matrix.matrix.clone(), new T.Color(color)]);
  }
  function texture(width, height, paint) {
    const c = document.createElement('canvas');
    c.width = width;
    c.height = height;
    paint(c.getContext('2d'));
    const map = new T.CanvasTexture(c);
    map.colorSpace = T.SRGBColorSpace;
    map.wrapS = map.wrapT = T.RepeatWrapping;
    return map;
  }
  function noise(ctx, size, count, scale = 1) {
    for (let i = 0; i < count; i++) {
      ctx.fillStyle =
        random() > 0.49 ? `rgba(255,248,215,${random() * 0.18})` : `rgba(28,27,18,${random() * 0.23})`;
      ctx.fillRect(
        random() * size,
        random() * size,
        scale * (0.3 + random() * 2),
        scale * (0.4 + random() * 1.5)
      );
    }
  }
  const skyTop = night ? '#435e79' : overcast ? '#7c8f96' : sand ? '#7cabb4' : '#779eae';
  const horizon = night ? '#b6b7ab' : overcast ? '#c6ccbe' : sand ? '#ead6a4' : '#ded7b9';
  scene.background = new T.Color(horizon);
  scene.fog = new T.FogExp2(horizon, weather === 'sandstorm' ? 0.00145 : overcast ? 0.00083 : 0.00063);
  const sky = new T.Mesh(
    new T.SphereGeometry(3800, 32, 16),
    new T.ShaderMaterial({
      side: T.BackSide,
      depthWrite: false,
      uniforms: { zenith: { value: new T.Color(skyTop) }, rim: { value: new T.Color(horizon) } },
      vertexShader:
        'varying vec3 dir;void main(){dir=position;gl_Position=projectionMatrix*modelViewMatrix*vec4(position,1.);}',
      fragmentShader: `uniform vec3 zenith,rim;varying vec3 dir;void main(){vec3 d=normalize(dir);
      float y=max(d.y,0.);vec3 c=mix(rim,zenith,smoothstep(0.,.76,pow(y,.75)));
      float s=max(dot(d,normalize(vec3(.82,.26,-.53))),0.);c+=vec3(.31,.21,.09)*pow(s,32.)+vec3(.8,.65,.4)*smoothstep(.99955,.9999,s);
      gl_FragColor=vec4(c,1.);
      #include <colorspace_fragment>
    }`
    })
  );
  sky.renderOrder = -2;
  scene.add(sky);
  scene.add(
    new T.HemisphereLight(night ? '#dae5f6' : '#fff6df', sand ? '#ac895a' : '#697064', night ? 1.75 : 1.85)
  );
  const sun = new T.DirectionalLight(night ? '#f5debd' : '#fff0d1', night ? 1.85 : 2.25);
  sun.position.set(-470, 740, -510);
  scene.add(sun);

  // Two ridgelines made of continuous, faceted terrain, behind the play area.
  for (let row = 0; row < 2; row++) {
    const pos = [],
      n = 84,
      radius = 1800 + row * 650,
      ridge = [];
    for (let i = 0; i < n; i++) {
      const a = (i * 2 * Math.PI) / n,
        r = radius + random() * 200;
      ridge.push([Math.cos(a) * r, (row ? 235 : 105) + Math.sin(a * 7) * 54 + random() * 100, Math.sin(a) * r]);
    }
    for (let i = 0; i < n; i++) {
      const a = ridge[i],
        b = ridge[(i + 1) % n],
        foot = (v) => [v[0] * 0.75, -14, v[2] * 0.75];
      pos.push(...foot(a), ...a, ...b, ...foot(a), ...b, ...foot(b));
    }
    const geo = new T.BufferGeometry();
    geo.setAttribute('position', new T.BufferAttribute(new Float32Array(pos), 3));
    geo.computeVertexNormals();
    scene.add(
      new T.Mesh(
        geo,
        new T.MeshLambertMaterial({
          color: sand ? '#ac805b' : row ? '#809393' : '#65796b',
          side: T.DoubleSide,
          flatShading: true
        })
      )
    );
  }
  const groundMap = texture(256, 256, (ctx) => {
    ctx.fillStyle = sand ? '#b49a6f' : city ? '#84846e' : '#7c895d';
    ctx.fillRect(0, 0, 256, 256);
    noise(ctx, 256, 2300, 3);
    noise(ctx, 256, 8200, 0.7);
    if (sand)
      for (let i = 0; i < 38; i++) {
        ctx.beginPath();
        ctx.strokeStyle = '#e4c98b35';
        const z = i * 7;
        ctx.moveTo(0, z);
        ctx.bezierCurveTo(80, z - 5, 167, z + 5, 256, z);
        ctx.stroke();
      }
  });
  groundMap.repeat.set(105, 105);
  const ground = new T.Mesh(new T.PlaneGeometry(6400, 6400), new T.MeshLambertMaterial({ map: groundMap }));
  ground.rotation.x = -Math.PI / 2;
  ground.position.y = -0.12;
  scene.add(ground);

  // Baked terrain layer, including road paint, to avoid z-fighting at road junctions.
  const W = BATTLE_AREA.x,
    H = BATTLE_AREA.y,
    tile = 1536;
  const surface = texture(tile, tile, (ctx) => {
    ctx.setTransform(tile / (2 * W), 0, 0, tile / (2 * H), tile / 2, tile / 2);
    for (const z of state.terrainZones) {
      ctx.fillStyle = { asphalt: '#626967', ice: '#abc6c0', mud: '#686147' }[z.type];
      ctx.fillRect(z.x, z.y, z.w, z.h);
    }
    if (city) {
      ctx.fillStyle = '#c8bd91';
      for (let x = -W; x < W; x += 54) ctx.fillRect(x, -1.2, 18, 2.4);
      ctx.fillStyle = '#aaa48c';
      for (const y of [-56, 55]) ctx.fillRect(-W, y, 2 * W, 1.6);
      for (const x of [-700, -280, 260, 720])
        for (let y = -H; y < H; y += 62) if (Math.abs(y) > 78) ctx.fillRect(x - 1, y, 2, 21);
    }
    for (const w of WeatherEngine.waterBodies) {
      ctx.fillStyle = '#699297';
      ctx.fillRect(w.x, w.y, w.w, w.h);
      ctx.fillStyle = '#c0d4c333';
      for (let i = 0; i < 70; i++) ctx.fillRect(w.x + random() * (w.w - 10), w.y + random() * w.h, 8, 1);
    }
    ctx.globalCompositeOperation = 'source-atop';
    ctx.setTransform(1, 0, 0, 1, 0, 0);
    noise(ctx, tile, 38000, 1.1);
  });
  const overlay = new T.Mesh(
    new T.PlaneGeometry(W * 2, H * 2),
    new T.MeshLambertMaterial({ map: surface, transparent: true, depthWrite: false })
  );
  overlay.rotation.x = -Math.PI / 2;
  overlay.position.y = 0.02;
  overlay.renderOrder = -1;
  scene.add(overlay);

  const neutral = (color) => new T.MeshLambertMaterial({ color });
  const roofMat = neutral('#505658'),
    edgeMat = neutral('#89918a');
  const wallViews = new Map();
  const facades = city
    ? ['#9c7764', '#a89678', '#89928b', '#8f7467'].map((color, index) => {
        const map = texture(384, 256, (ctx) => {
          ctx.fillStyle = color;
          ctx.fillRect(0, 0, 384, 256);
          ctx.fillStyle = '#3a3c321a';
          for (let y = 0; y < 256; y += 8) {
            ctx.fillRect(0, y, 384, 1);
            for (let x = y % 16 ? 0 : -14; x < 384; x += 28) ctx.fillRect(x, y, 1, 8);
          }
          noise(ctx, 384, 4200, 1);
          for (let row = 0; row < 2; row++)
            for (let col = 0; col < 5; col++) {
              const x = 11 + col * 76,
                y = 29 + row * 93;
              ctx.fillStyle = '#655e50';
              ctx.fillRect(x - 3, y - 2, 56, 46);
              ctx.fillStyle = night ? '#c8b788' : '#435051';
              ctx.fillRect(x, y, 50, 40);
              ctx.fillStyle = night ? '#847960' : '#697778';
              ctx.fillRect(x + 2, y + 1, 21, 17);
              ctx.fillRect(x + 27, y + 21, 20, 16);
              ctx.fillStyle = '#888372';
              ctx.fillRect(x + 23, y, 3, 40);
              ctx.fillRect(x, y + 18, 50, 3);
              ctx.fillStyle = '#b5a78b';
              ctx.fillRect(x - 4, y + 40, 58, 4);
            }
          ctx.fillStyle = '#625d51';
          ctx.fillRect(0, 224, 384, 32);
          // A recessed roll-up door, service sign and enamel hazard stripes on each shop.
          const door = index % 2 ? 226 : 16;
          ctx.fillStyle = '#494c45';
          ctx.fillRect(door - 5, 136, 125, 120);
          ctx.fillStyle = '#69746d';
          ctx.fillRect(door, 143, 115, 113);
          ctx.fillStyle = '#3c4845';
          for (let y = 145; y < 256; y += 7) ctx.fillRect(door, y, 115, 1.7);
          for (let y = 148; y < 250; y += 15) {
            ctx.fillStyle = '#d6ac64';
            ctx.fillRect(door - 5, y, 5, 7);
            ctx.fillRect(door + 115, y, 5, 7);
          }
          const label = index % 2 ? 18 : 181;
          ctx.fillStyle = '#465e5c';
          ctx.fillRect(label, 172, 120, 37);
          ctx.strokeStyle = '#b4b6a0';
          ctx.strokeRect(label + 3, 175, 114, 31);
          ctx.fillStyle = '#e2d7b5';
          ctx.font = 'bold 21px monospace';
          ctx.fillText('ЦЕХ  0' + (index + 1), label + 11, 199);
          ctx.fillStyle = '#9c9b89';
          ctx.fillRect(371, 10, 4, 232);
          ctx.fillStyle = '#6a685a';
          for (let y = 22; y < 240; y += 47) ctx.fillRect(369, y, 8, 3);
        });
        return new T.MeshLambertMaterial({ map });
      })
    : [];
  function part(parent, geo, mat, x, y, z, w, h, d) {
    const mesh = new T.Mesh(geo, mat);
    mesh.position.set(x, y, z);
    mesh.scale.set(w, h, d);
    parent.add(mesh);
    return mesh;
  }
  const shadow = texture(64, 64, (ctx) => {
    const g = ctx.createRadialGradient(32, 32, 9, 32, 32, 32);
    g.addColorStop(0, 'rgba(28,24,18,.58)');
    g.addColorStop(1, 'rgba(28,24,18,0)');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, 64, 64);
  });
  const shadowMat = new T.MeshBasicMaterial({
    map: shadow,
    transparent: true,
    depthWrite: false,
    polygonOffset: true,
    polygonOffsetFactor: -2
  });
  const floorQuad = new T.PlaneGeometry();
  for (const [i, w] of state.walls.entries()) {
    const x = w.x + w.w / 2,
      z = w.y + w.h / 2,
      h = w.height;
    const group = new T.Group();
    group.position.set(x, 0, z);
    scene.add(group);
    wallViews.set(w, group);
    const shade = part(group, floorQuad, shadowMat, -w.w * 0.13, 0.09, w.h * 0.12, w.w * 1.72, w.h * 1.72, 1);
    shade.rotation.x = -Math.PI / 2;
    if (w.type === 'building') {
      part(group, box, facades[i % facades.length], 0, h / 2, 0, w.w, h, w.h);
      part(group, box, edgeMat, 0, h, 0, w.w + 2, 2, w.h + 2);
      part(group, box, roofMat, 0, h + 1.45, 0, w.w, 0.9, w.h);
      if (i % 2 === 0) {
        part(group, box, roofMat, -w.w * 0.19, h + 3, -w.h * 0.16, 14, 6, 20);
        part(group, cylinder, edgeMat, w.w * 0.23, h + 4, 0, 4, 9, 4);
      }
    } else if (w.solid) {
      const rock = part(
        group,
        crown,
        neutral(sand ? '#af8c65' : '#8a8978'),
        0,
        h * 0.43,
        0,
        w.w * 1.18,
        h * 1.28,
        w.h * 1.2
      );
      rock.rotation.y = i * 0.38;
    } else {
      part(group, crown, neutral(sand ? '#bd996b' : '#626e45'), 0, h * 0.32, 0, w.w, h, w.h);
    }
  }
  if (city) {
    // Verges, loading aprons and lamp standards. Keep decoration off the driving lane.
    for (const sign of [-1, 1]) {
      for (const [a, b] of [
        [-1040, -748],
        [-650, -330],
        [-230, 211],
        [308, 669],
        [770, 1040]
      ]) {
        place(box, (a + b) / 2, 0.2, sign * 69, b - a, 0.55, 10, '#96978a');
        for (let x = a + 5; x < b; x += 25) place(box, x, 0.52, sign * 69, 0.45, 0.14, 9.6, '#696c63');
      }
      for (let i = 0; i < 7; i++) {
        const x = -908 + i * 307,
          z = sign * 83;
        place(cylinder, x, 12.5, z, 1.05, 25, 1.05, '#64685b');
        place(cylinder, x, 2.5, z, 2.1, 5, 2.1, '#757867');
        place(box, x, 25.1, z - sign * 4.2, 1, 1, 9.3, '#62675d');
        place(box, x, 24.7, z - sign * 9, 2.4, 1.5, 4.3, '#62675d');
        place(box, x, 23.85, z - sign * 9, 2.1, 0.42, 3.8, '#f0dfa1');
      }
    }
  }
  // Tree belts and industrial silhouettes are outside the driveable area.
  function tree(x, z, h) {
    place(cylinder, x, h * 0.22, z, h * 0.1, h * 0.45, h * 0.1, '#716757');
    if (!city && random() < 0.52) {
      place(pine, x, h * 0.63, z, h * 0.48, h * 0.82, h * 0.46, '#596c59');
      place(pine, x, h * 0.84, z, h * 0.31, h * 0.53, h * 0.31, '#637665');
    } else {
      const c = ['#77805b', '#697554', '#888a60'][Math.floor(random() * 3)];
      place(crown, x, h * 0.65, z, h * 0.56, h * 0.72, h * 0.58, c, random() * 6);
    }
  }
  for (let i = 0; i < (sand ? 55 : 200); i++) {
    let a = random() * Math.PI * 2,
      x = Math.cos(a) * (W + 100 + random() * 330),
      z = Math.sin(a) * (H + 105 + random() * 340);
    if (Math.abs(x) < W + 32 && Math.abs(z) < H + 32) continue;
    if (sand) place(crown, x, 3, z, 22 + random() * 33, 10 + random() * 16, 25, '#ae8c6b', a);
    else tree(x, z, 29 + random() * 46);
  }
  if (city)
    for (const side of [-1, 1]) {
      for (let i = 0; i < 4; i++) {
        const x = side * (W + 125 + i * 56),
          z = side * (-140 + i * 90),
          h = 138 + i * 17;
        place(cylinder, x, h / 2, z, 18, h, 18, '#92816d');
        for (let k = 0; k < 3; k++) place(cylinder, x, h * 0.76 + k * 12, z, 18.3, 6, 18.3, '#b5a896');
        place(box, x - 48, 21, z, 74, 42, 105, '#8c8980');
        place(box, x - 48, 43, z, 77, 4, 109, '#626e70');
      }
      for (let i = 0; i < 6; i++) {
        const x = side * (W + 85),
          z = 240 + i * 50;
        place(cylinder, x, 33, z, 38, 66, 38, '#a6aca0');
        place(pine, x, 70, z, 42, 11, 42, '#67777a');
      }
    }
  // Perimeter stakes make the driveable boundary legible even in open country.
  for (let x = -W; x <= W; x += 70)
    for (const z of [-H, H]) {
      place(box, x, 5, z, 3, 10, 3, '#ddd4af');
      place(box, x, 8, z, 3.2, 3, 3.2, '#ab6a46');
    }
  for (let z = -H; z <= H; z += 70)
    for (const x of [-W, W]) {
      place(box, x, 5, z, 3, 10, 3, '#ddd4af');
      place(box, x, 8, z, 3.2, 3, 3.2, '#ab6a46');
    }
  for (const [geo, list] of batches) {
    const m = new T.InstancedMesh(geo, matte, list.length);
    list.forEach(([transform, color], i) => {
      m.setMatrixAt(i, transform);
      m.setColorAt(i, color);
    });
    scene.add(m);
  }
  return { wallViews, shadowMat };
}
