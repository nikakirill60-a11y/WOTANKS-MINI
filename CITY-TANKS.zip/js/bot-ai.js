// Arcade bot controller. Decisions use team sightings; losing sight leaves a point in
// memory, not a live pointer to the hidden vehicle's position. Driving and reloads use
// exactly the same collision, terrain and Tank.fire code as the player's vehicle.
const BotAI = (() => {
  let plansLeft = 0;
  const turn = (to, from) => Math.atan2(Math.sin(to - from), Math.cos(to - from));
  const limit = (v, n) => Math.max(-n, Math.min(n, v));
  function attach(u, slot, nav) {
    const { arena } = nav,
      other = arena.bases[1 - slot.side],
      hub = arena.hubs[slot.lane];
    const jitter = (Math.floor(slot.index / 3) - 1) * 32;
    const goals = [
      { x: hub.x + jitter, y: hub.y + jitter * 0.55 },
      { x: other.x, y: other.y + jitter },
      arena.hubs[(slot.lane + 1) % 3]
    ];
    // If contact never comes (or is lost), search beyond the original meeting lanes.
    // These are public map locations, never unspotted opposing spawn occupants.
    const { x: W, y: H } = arena.bounds;
    for (let i = 0; i < 7; i++) {
      const row = (i + slot.lane * 2 + slot.side) % 7,
        y = (row - 3) * H * 0.28;
      const x = W * 0.86 * (i % 2 === slot.side ? 1 : -1);
      goals.push({ x, y }, { x: -x, y });
    }
    u.bot = {
      order: slot.index + slot.side * 10,
      mode: 'advance',
      patrol: goals.map((p) => nav.point(nav.nearest(p.x, p.y))),
      leg: 0,
      ideal: 155 + (DB[u.id].cls === 'ht' ? 70 : 25) + (slot.index % 3) * 12,
      target: null,
      memory: null,
      open: false,
      aimTicks: 0,
      nextLook: 1 + ((slot.index * 3) % 16),
      path: [],
      at: 0,
      goal: null,
      planAfter: 0,
      revision: -1,
      steerAt: 0,
      heading: u.angle,
      blocked: 0,
      backup: 0,
      crowded: false,
      yieldUntil: 0,
      sideStep: null,
      shift: false,
      shell: 0
    };
  }
  function beginTick(nav) {
    plansLeft = 2;
    if (nav && nav.revision !== nav.arena.revision) nav.rebuild();
  }
  function observe(u, b, now) {
    const previous = b.target;
    let best = null,
      score = Infinity,
      line = false;
    for (const t of GameState.units) {
      if (t.dead || !t.spotted || (t.team === 'enemy') === (u.team === 'enemy')) continue;
      const d = Math.hypot(t.x - u.x, t.y - u.y);
      if (d > 1250) continue;
      const open = d <= 580 && clearBattleSight(u, t);
      const s = d + (open ? 0 : 400) - (t === previous ? 90 : 0) - (t.hp <= u.dmg ? 48 : 0);
      if (s < score) {
        best = t;
        score = s;
        line = open;
      }
    }
    if (previous !== best) {
      b.aimTicks = 0;
      b.shell = 0;
      b.shift = false;
      b.yieldUntil = 0;
    }
    b.target = best;
    b.open = line;
    b.nextLook = now + 16;
    if (best) b.memory = { x: best.x, y: best.y, until: now + 300 };
  }
  function friendInWay(u, t) {
    const dx = t.x - u.x,
      dy = t.y - u.y,
      d2 = dx * dx + dy * dy;
    return GameState.units.some((a) => {
      if (a === u || a.dead || (a.team === 'enemy') !== (u.team === 'enemy') || !d2) return false;
      const k = ((a.x - u.x) * dx + (a.y - u.y) * dy) / d2;
      return k > 0 && k < 1 && (a.x - u.x - k * dx) ** 2 + (a.y - u.y - k * dy) ** 2 < (13 * a.s) ** 2;
    });
  }
  function sidestep(u, b, dx, dy, nav) {
    const preferred = b.order % 2 ? 1 : -1;
    for (const sign of [preferred, -preferred]) {
      const x = u.x - dy * sign * 94,
        y = u.y + dx * sign * 94;
      if (nav.clear(u.x, u.y, x, y)) return { x, y };
    }
    return nav.point(nav.nearest(u.x - dx * 80, u.y - dy * 80));
  }
  // Only react to feedback from an actual blocked hit on the current, spotted target.
  function onBlockedHit(u, t) {
    const b = u.bot;
    if (b?.target !== t || !t.spotted) return;
    b.shell = u.usesMagazine ? 0 : 2;
    b.shift = true;
  }
  function nextLeg(b) {
    if (++b.leg >= b.patrol.length) b.leg = 3;
    b.path = [];
    b.goal = null;
    b.at = 0;
  }
  function steer(u, b, p, nav, now) {
    const dist = Math.hypot(p.x - u.x, p.y - u.y),
      wanted = Math.atan2(p.y - u.y, p.x - u.x);
    if (now >= b.steerAt) {
      b.steerAt = now + 7;
      const look = Math.min(58, dist),
        others = GameState.units.filter(
          (a) => a !== u && !a.dead && Math.abs(a.x - u.x) < 108 && Math.abs(a.y - u.y) < 108
        );
      let best = Infinity;
      for (const offset of [0, 0.42, -0.42, 0.82, -0.82, 1.25, -1.25, 1.7, -1.7, 2.35, -2.35, Math.PI]) {
        const a = wanted + offset,
          dx = Math.cos(a),
          dy = Math.sin(a);
        if (!nav.clear(u.x, u.y, u.x + dx * look, u.y + dy * look)) continue;
        let cost = Math.abs(offset) + 0.16 * Math.abs(turn(a, u.angle));
        for (const o of others) {
          const ox = o.x - u.x,
            oy = o.y - u.y,
            along = ox * dx + oy * dy;
          if (along <= 0) continue;
          const step = Math.min(look, along),
            d = Math.hypot(ox - step * dx, oy - step * dy);
          cost += Math.max(0, (u.s + o.s) * 24 - d) * 0.16;
        }
        if (cost < best) {
          best = cost;
          b.heading = a;
        }
      }
      if (!Number.isFinite(best)) b.heading = wanted;
    }
    const delta = turn(b.heading, u.angle);
    u.angle += limit(delta, 0.043 * getTerrainTurnMul(u));
    if (Math.abs(delta) > 1.05) return; // turn in place, don't slide sideways through corners
    const speed = Math.min(dist, driveSpeed(u) * 0.95);
    if (
      nav.clear(u.x, u.y, u.x + Math.cos(u.angle) * speed, u.y + Math.sin(u.angle) * speed) &&
      tryDrive(u, speed)
    )
      b.blocked = 0;
    else {
      b.steerAt = 0;
      if (++b.blocked >= 35) {
        b.crowded = true;
        b.backup = 22;
        b.blocked = 0;
        b.planAfter = now + 22;
      }
    }
  }
  function follow(u, b, goal, nav, now) {
    if (b.backup > 0) {
      b.backup--;
      const v = -driveSpeed(u) * 0.58;
      if (nav.clear(u.x, u.y, u.x + v * Math.cos(u.angle), u.y + v * Math.sin(u.angle))) tryDrive(u, v);
      return;
    }
    const changed = !b.goal || Math.hypot(goal.x - b.goal.x, goal.y - b.goal.y) > 80;
    const stale = b.revision !== nav.revision;
    if ((changed || stale || b.crowded || !b.path.length) && now >= b.planAfter && plansLeft > 0) {
      plansLeft--;
      const traffic = b.crowded
        ? GameState.units.filter((a) => a !== u && !a.dead && Math.hypot(a.x - u.x, a.y - u.y) < 220)
        : [];
      b.path = nav.route(u, goal, traffic);
      b.at = 0;
      b.goal = { x: goal.x, y: goal.y };
      b.crowded = false;
      b.revision = nav.revision;
      b.planAfter = now + 36 + (b.order % 9);
      b.steerAt = 0;
    }
    while (b.at < b.path.length && Math.hypot(b.path[b.at].x - u.x, b.path[b.at].y - u.y) < 17) {
      b.at++;
      b.steerAt = 0;
    }
    if (b.at >= b.path.length) {
      if (b.path.length && !changed) {
        if (b.mode === 'advance') nextLeg(b);
        else if (b.mode === 'search') b.memory = null;
      }
      b.path = [];
      return;
    }
    steer(u, b, b.path[b.at], nav, now);
  }
  function step(u, now) {
    u.isMoving = false;
    if (u.practiceTarget) return;
    const b = u.bot,
      nav = GameState.navigation;
    if (b.target?.dead) {
      b.target = null;
      b.memory = null;
      b.aimTicks = 0;
      b.nextLook = now;
    } else if (b.target && !b.target.spotted) {
      b.target = null;
      b.aimTicks = 0;
      b.nextLook = now;
    }
    if (now >= b.nextLook) observe(u, b, now);
    const t = b.target;
    let dest = null,
      mode = 'advance';
    if (t) {
      const dx = t.x - u.x,
        dy = t.y - u.y,
        d = Math.max(1, Math.hypot(dx, dy)),
        a = Math.atan2(dy, dx);
      u.tAngle += limit(turn(a, u.tAngle), 0.042);
      u.aimPitch = Math.atan2(t.aimHeight - u.gunHeight, d);
      const ready = b.open && Math.abs(turn(a, u.tAngle)) < 0.055;
      b.aimTicks = ready ? b.aimTicks + 1 : 0;
      const closeAlly = b.open && friendInWay(u, t);
      const stand = b.ideal + (u.hp < u.maxHp * 0.4 ? 40 : 0);
      if (b.open && now >= b.yieldUntil && (b.shift || (closeAlly && d < stand + 80))) {
        b.sideStep = sidestep(u, b, dx / d, dy / d, nav);
        b.yieldUntil = now + 90;
      }
      b.shift = false;
      if (b.open && d < stand * 0.62) {
        mode = 'space';
        dest = { x: u.x - (dx / d) * 85, y: u.y - (dy / d) * 85 };
      } else if (b.open && now < b.yieldUntil) {
        mode = 'space';
        dest = b.sideStep;
      } else if (!b.open || d > stand + 28) {
        mode = 'approach';
        dest = t;
      } else mode = 'engage';
      // Recheck the shot now; a sighting/clear segment from the last decision isn't a firing permit.
      if (
        b.aimTicks >= 18 + (b.order % 9) &&
        !closeAlly &&
        !u.isReloading &&
        performance.now() >= u.nextShot &&
        clearBattleSight(u, t)
      ) {
        const m = u.muzzle(),
          flat = Math.cos(u.aimPitch);
        // Use the actual muzzle and barrel direction (not a ray to the centre of a marker).
        // Friendly vehicles block this check even in a mode without friendly damage.
        const shot = traceBattleRay(
          m.x,
          m.y,
          m.h,
          Math.cos(u.tAngle) * flat,
          Math.sin(u.tAngle) * flat,
          Math.sin(u.aimPitch),
          d + 40,
          u,
          false,
          true
        );
        if (shot.hit === t) u.fire(b.shell);
        else if (b.mode === 'engage') b.shift = true;
      }
    } else {
      const seen = b.memory;
      if (seen && now < seen.until && Math.hypot(u.x - seen.x, u.y - seen.y) > 26) {
        mode = 'search';
        dest = seen;
      } else {
        b.memory = null;
        dest = b.patrol[b.leg];
      }
      const look = mode === 'search' ? Math.atan2(dest.y - u.y, dest.x - u.x) : u.angle;
      u.tAngle += limit(turn(look, u.tAngle), 0.035);
      u.aimPitch = 0;
    }
    if (b.mode !== mode) {
      b.goal = null;
      b.path = [];
      b.at = 0;
      b.planAfter = now;
      b.steerAt = 0;
      b.mode = mode;
    }
    if (dest) follow(u, b, dest, nav, now);
    applyIceDrift(u);
  }
  return { attach, beginTick, step, onBlockedHit };
})();
