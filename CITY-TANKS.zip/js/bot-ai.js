// Arcade bot controller. Decisions use team sightings; losing sight leaves a point in
// memory, not a live pointer to the hidden vehicle's position. Driving and reloads use
// exactly the same collision, terrain and Tank.fire code as the player's vehicle.
const BotAI = (() => {
  let plansLeft = 0;
  const turn = (to, from) => Math.atan2(Math.sin(to - from), Math.cos(to - from));
  const limit = (v, n) => Math.max(-n, Math.min(n, v));
  function attach(u, slot, nav) {
    if (!nav.recon) nav.recon = new BattleRecon(nav);
    const hub = nav.arena.hubs[slot.lane];
    const post = u.isSPG ? { x:u.x, y:u.y } : null;
    const scout = !!slot.scout && !post;
    // Supporters open in the same five corridors, but not at a scout's exact
    // destination or at each other's parking spot. Then they also survey sectors.
    const offset = ((slot.index % 3) - 1) * 76,
      side = slot.side ? 1 : -1;
    const opening = post || scout ? null : nav.point(
      nav.nearest(hub.x + offset * side, hub.y + side * ((slot.index % 4) - 1.5) * 54)
    );
    u.bot = {
      order: slot.index * 2 + slot.side,
      side: slot.side,
      scout, hub, opening, post,
      board: post ? new ArtillerySight(nav.arena.bounds, post) : null,
      regroupUntil: 0,
      rally: null, stand: null,
      openingDistance: Infinity,
      openingUntil: 0,
      firstSurvey: scout,
      sector: -1,
      skipSector: -1,
      radio: null,
      mode: post ? 'base' : 'advance',
      ideal: 155 + (DB[u.id].cls === 'ht' ? 70 : 25) + (slot.index % 3) * 12,
      target: null,
      memory: null,
      open: false,
      aimTicks: 0,
      nextLook: 1 + ((slot.index * 3) % 16),
      path: [],
      at: 0,
      goal: null,
      planAfter: 0,
      revision: -1,
      steerAt: 0,
      heading: u.angle,
      blocked: 0,
      backup: 0,
      crowded: false,
      yieldUntil: 0,
      sideStep: null,
      shift: false,
      shell: 0
    };
  }
  function beginTick(nav, now) {
    plansLeft = 2;
    if (!nav) return;
    if (nav.revision !== nav.arena.revision) {
      nav.rebuild();
      nav.recon?.rebuild();
    }
    if (now === 1 || now % 12 === 0) nav.recon?.sample(GameState.units, now);
  }
  // Take one short step back towards the team's map marker, then wait there.
  // If home is beyond the contact, holding is better than driving through it.
  function rallyPoint(u, b, contact, nav) {
    const home = nav.arena.bases[b.side], dx = home.x - u.x, dy = home.y - u.y;
    const d = Math.hypot(dx, dy);
    if (d < 80 || dx * (contact.x - u.x) + dy * (contact.y - u.y) > 0) return null;
    const k = Math.min(1, 230 / d);
    const n = nav.nearest(u.x + dx * k, u.y + dy * k);
    return n < 0 ? null : nav.point(n);
  }
  function observe(u, b, now) {
    const previous = b.target;
    let best = null,
      score = Infinity,
      line = false, friends = 1, contacts = 0;
    for (const t of GameState.units) {
      if (t === u || t.dead) continue;
      if ((t.team === 'enemy') === (u.team === 'enemy')) {
        if ((t.x - u.x) ** 2 + (t.y - u.y) ** 2 <= 480 ** 2) friends++;
        continue;
      }
      if (!t.spotted) continue;
      const d = Math.hypot(t.x - u.x, t.y - u.y);
      if (!b.post && d > 1250) continue;
      if (d <= 600) contacts++;
      const open = !b.post && d <= 580 && clearBattleSight(u, t);
      const s = d + (open ? 0 : 400) - (t === previous ? 90 : 0) - (t.hp <= u.dmg ? 48 : 0);
      if (s < score) {
        best = t;
        score = s;
        line = open;
      }
    }
    if (previous !== best) {
      b.aimTicks = 0;
      b.shell = 0;
      b.shift = false;
      b.yieldUntil = 0;
    }
    b.target = best;
    b.open = line;
    b.nextLook = now + 16;
    if (b.post) {
      // Only a current team sighting can move the NPC's arcade board cursor.
      if (previous !== best) b.board.focus = 0;
      if (best) b.board.moveTo(best.x, best.y);
      return;
    }
    if (!b.stand && best && (contacts > friends || u.hp <= u.maxHp * .35)) {
      if (now >= b.regroupUntil) b.rally = rallyPoint(u, b, best, GameState.navigation);
      b.regroupUntil = now + 120; // don't immediately chase when a contact blinks out
    }
    b.radio = !b.stand && !best && !b.scout ? GameState.navigation.recon.report(u, now) : null;
    if (best) b.memory = { x: best.x, y: best.y, until: now + BattleRecon.reportLife };
  }
  function friendInWay(u, t) {
    const dx = t.x - u.x,
      dy = t.y - u.y,
      d2 = dx * dx + dy * dy;
    return GameState.units.some((a) => {
      if (a === u || a.dead || (a.team === 'enemy') !== (u.team === 'enemy') || !d2) return false;
      const k = ((a.x - u.x) * dx + (a.y - u.y) * dy) / d2;
      return k > 0 && k < 1 && (a.x - u.x - k * dx) ** 2 + (a.y - u.y - k * dy) ** 2 < (13 * a.s) ** 2;
    });
  }
  function sidestep(u, b, dx, dy, nav) {
    const preferred = (b.order >> 1) % 2 ? 1 : -1;
    for (const sign of [preferred, -preferred]) {
      const x = u.x - dy * sign * 94,
        y = u.y + dx * sign * 94;
      if (nav.clear(u.x, u.y, x, y)) return { x, y };
    }
    return nav.point(nav.nearest(u.x - dx * 80, u.y - dy * 80));
  }
  // Only react to feedback from an actual blocked hit on the current, spotted target.
  function onBlockedHit(u, t) {
    const b = u.bot;
    if (b?.target !== t || !t.spotted || b.post) return;
    if (u.calibration) {
      b.shell = 1; // This loadout's alternate is КС, not the ordinary slot-3 Подкал.
      if (!u.calibration.active) u.toggleCalibration();
    } else b.shell = u.usesMagazine ? 0 : 2;
    b.shift = true;
  }
  function steer(u, b, p, nav, now) {
    const dist = Math.hypot(p.x - u.x, p.y - u.y),
      wanted = Math.atan2(p.y - u.y, p.x - u.x);
    if (now >= b.steerAt) {
      b.steerAt = now + 7;
      const look = Math.min(58, dist),
        others = GameState.units.filter(
          (a) => a !== u && !a.dead && Math.abs(a.x - u.x) < 108 && Math.abs(a.y - u.y) < 108
        );
      let best = Infinity;
      for (const offset of [0, 0.42, -0.42, 0.82, -0.82, 1.25, -1.25, 1.7, -1.7, 2.35, -2.35, Math.PI]) {
        const a = wanted + offset,
          dx = Math.cos(a),
          dy = Math.sin(a);
        if (!nav.clear(u.x, u.y, u.x + dx * look, u.y + dy * look)) continue;
        let cost = Math.abs(offset) + 0.16 * Math.abs(turn(a, u.angle));
        for (const o of others) {
          const ox = o.x - u.x,
            oy = o.y - u.y,
            along = ox * dx + oy * dy;
          if (along <= 0) continue;
          const step = Math.min(look, along),
            d = Math.hypot(ox - step * dx, oy - step * dy);
          cost += Math.max(0, (u.s + o.s) * 24 - d) * 0.16;
        }
        if (cost < best) {
          best = cost;
          b.heading = a;
        }
      }
      if (!Number.isFinite(best)) b.heading = wanted;
    }
    const delta = turn(b.heading, u.angle);
    b.steer = limit(delta / 0.12, 1);
    const stoppingDistance = (u.driveSpeed ** 2 / (2 * 5.5)) * BATTLE_UNITS_PER_METRE;
    b.brake = Math.abs(delta) > 1.02 || stoppingDistance > dist;
    // Approach a corner at a speed that leaves room to brake. Do not bypass
    // inertia by writing positions, including during traffic recovery.
    if (!b.brake) {
      b.throttle = Math.min(0.95, 0.32 + dist / 95) * (1 - 0.37 * Math.abs(delta));
      // Don't try to creep up a grade on too little throttle to move at all.
      if (u.driveSpeed < 2 && u.groundPitch > 0) {
        const grade = 9.81 * 0.85 * Math.sin(u.groundPitch),
          drag = 0.045 * 9.81 * CONFIG.TERRAIN[u.currentTerrain].resistance;
        b.throttle = Math.max(b.throttle, Math.min(1, (grade + drag + 0.3) / 2.6));
      }
    }
  }
  function follow(u, b, goal, nav, now) {
    if (b.backup > 0) {
      b.backup--;
      b.throttle = -1;
      b.brake = false;
      return;
    }
    const changed = !b.goal || Math.hypot(goal.x - b.goal.x, goal.y - b.goal.y) > 80;
    const stale = b.revision !== nav.revision;
    if ((changed || stale || b.crowded || !b.path.length) && now >= b.planAfter && plansLeft > 0) {
      plansLeft--;
      const traffic = b.crowded
        ? GameState.units.filter((a) => a !== u && !a.dead && Math.hypot(a.x - u.x, a.y - u.y) < 220)
        : [];
      b.path = nav.route(u, goal, traffic);
      b.at = 0;
      b.goal = { x: goal.x, y: goal.y };
      b.crowded = false;
      b.revision = nav.revision;
      b.planAfter = now + 36 + (b.order % 9);
      b.steerAt = 0;
    }
    while (b.at < b.path.length && Math.hypot(b.path[b.at].x - u.x, b.path[b.at].y - u.y) < 17) {
      b.at++;
      b.steerAt = 0;
    }
    if (b.at >= b.path.length) {
      if (b.path.length && !changed) {
        if (b.mode === 'advance') b.opening = null;
        else if (b.mode === 'search') b.memory = null;
      }
      b.path = [];
      return;
    }
    steer(u, b, b.path[b.at], nav, now);
  }
  function drive(u, b, mode, dest, nav, now) {
    if (mode !== 'survey' && b.sector >= 0) nav.recon.release(u);
    if (b.mode !== mode) {
      b.goal = null;
      b.path = [];
      b.at = 0;
      b.planAfter = now;
      b.steerAt = 0;
      if (mode === 'regroup' || mode === 'return' || mode === 'lastStand') {
        b.backup = b.blocked = 0; // discard recovery inputs for the previous route
        b.crowded = false;
      }
      b.mode = mode;
    }
    if (dest) follow(u, b, dest, nav, now);
    TrackDrive.step(u, b.throttle, b.steer, b.brake, nav);
    if (b.throttle > 0 && u.driveBlocked) {
      b.steerAt = 0;
      if (++b.blocked >= 35) {
        b.crowded = true;
        b.backup = 96;
        b.blocked = 0;
        b.planAfter = now + b.backup;
      }
    } else if (u.isMoving) b.blocked = 0;
  }
  function guardBase(u, b, nav, now) {
    // Collisions still apply. If pushed away, drive back to the original safe
    // berth; never give an SPG a scout, search, sidestep or pursuit destination.
    if (Math.hypot(u.x - b.post.x, u.y - b.post.y) > (b.mode === 'return' ? 24 : 65)) {
      b.board.focus = 0;
      drive(u, b, 'return', b.post, nav, now);
      return;
    }
    const sight = b.board;
    if (b.target) {
      b.steer = sight.steer(u);
      sight.step(u, 1 / 60, false);
      if (!u.isReloading && sight.focus >= .55) {
        const margin = ArtillerySight.burstRadius + sight.radius;
        const allyInCircle = GameState.units.some(a => !a.dead && (a.team === 'enemy') === (u.team === 'enemy') &&
          (a.x - sight.x) ** 2 + (a.y - sight.y) ** 2 < margin ** 2);
        if (!allyInCircle) u.fire(0, sight); // same in-game cursor, projectile and reload as the player
      }
    } else sight.focus = 0;
    drive(u, b, 'base', null, nav, now);
  }
  function step(u, now) {
    u.isMoving = false;
    if (u.practiceTarget) return;
    const b = u.bot,
      nav = GameState.navigation;
    b.throttle = b.steer = 0;
    b.brake = true;
    if (b.target?.dead) {
      b.target = null;
      b.memory = null;
      b.aimTicks = 0;
      b.nextLook = now;
    } else if (b.target && !b.target.spotted) {
      b.target = null;
      b.aimTicks = 0;
      b.nextLook = now;
    }
    if (now >= b.nextLook) observe(u, b, now);
    if (b.post) return guardBase(u, b, nav, now);
    const t = b.target, cautious = !b.stand && now < b.regroupUntil;
    const berth = b.stand && Math.hypot(u.x - b.stand.x, u.y - b.stand.y) > 24 ? b.stand : null;
    const rally = cautious && b.rally && Math.hypot(u.x - b.rally.x, u.y - b.rally.y) > 28 ? b.rally : null;
    let dest = null,
      mode = 'advance';
    if (t) {
      b.opening = null;
      b.firstSurvey = false;
      const dx = t.x - u.x,
        dy = t.y - u.y,
        d = Math.max(1, Math.hypot(dx, dy));
      const bearing = u.lookAtPoint(t.x, t.y, t.aimHeight);
      u.slewDriver(1 / 60);
      const outOfArc =
        u.minYaw === u.maxYaw ? Math.abs(turn(bearing, u.angle)) > 0.007 : !u.canTraverseTo(bearing);
      const ready = b.open && !outOfArc && Math.abs(turn(u.lookYaw, u.tAngle)) < 0.035;
      b.aimTicks = ready ? b.aimTicks + 1 : 0;
      const closeAlly = b.open && friendInWay(u, t);
      const stand = b.ideal + (u.hp < u.maxHp * 0.4 ? 40 : 0);
      if (!b.stand && !cautious && b.open && now >= b.yieldUntil && (b.shift || (closeAlly && d < stand + 80))) {
        b.sideStep = sidestep(u, b, dx / d, dy / d, nav);
        b.yieldUntil = now + 90;
      }
      b.shift = false;
      if (b.stand) {
        mode = 'lastStand';
        // Fight on contact; don't flee on reload or chase a fading sighting.
        if (!b.open || closeAlly) dest = berth;
      } else if (cautious) {
        mode = 'regroup';
        // Hold an available shot, otherwise fall back a short distance, not all
        // the way across the map. Still use ordinary movement and shot checks.
        if (!b.open || closeAlly || u.isReloading || d < stand) dest = rally;
      } else if (b.open && d < stand * 0.62) {
        mode = 'space';
        dest = { x: u.x - (dx / d) * 85, y: u.y - (dy / d) * 85 };
      } else if (b.open && now < b.yieldUntil) {
        mode = 'space';
        dest = b.sideStep;
      } else if (!b.open) {
        mode = 'approach';
        dest = t;
      } else mode = 'engage'; // already in range: don't keep closing just to reach a waypoint
      if (!dest && outOfArc) b.steer = limit(turn(bearing, u.angle) / 0.12, 1);
      // Recheck the shot now; a sighting/clear segment from the last decision isn't a firing permit.
      if (
        b.aimTicks >= 18 + (b.order % 9) &&
        !closeAlly &&
        !u.isReloading &&
        BattleClock.now() >= u.nextShot &&
        clearBattleSight(u, t)
      ) {
        // Check the actual barrel(s), including friendly cover, not an imaginary centre shot.
        const clear = u.modelAsset?.muzzles
          ? u.modelAsset.muzzles.every(tip => u.sightHit(d + 40, true, false, tip).hit === t)
          : u.sightHit(d + 40, true).hit === t;
        if (clear) u.fire(b.shell);
        else if (b.mode === 'engage') b.shift = true;
      }
    } else if (b.stand) {
      mode = 'lastStand'; dest = berth;
      u.setLook(u.angle, 0);
      u.slewDriver(1 / 60);
    } else if (cautious) {
      mode = 'regroup'; dest = rally;
    } else {
      if (b.opening) {
        const d = Math.hypot(u.x - b.opening.x, u.y - b.opening.y);
        if (d < b.openingDistance - 18) {
          b.openingDistance = d;
          b.openingUntil = now + 540;
        }
        if (d < 17 || now >= b.openingUntil) b.opening = null;
      }
      const seen = b.memory;
      if (seen && now < seen.until && Math.hypot(u.x - seen.x, u.y - seen.y) > 26) {
        mode = 'search';
        dest = seen;
      } else {
        b.memory = null;
        if (b.radio && b.radio.until > now && Math.hypot(u.x - b.radio.x, u.y - b.radio.y) > 50) {
          mode = 'investigate';
          dest = b.radio;
          b.opening = null;
        } else if (b.opening) {
          dest = b.opening;
        } else {
          mode = 'survey';
          dest = nav.recon.destination(u, now);
        }
      }
      // Sweep the in-game turret on survey runs. Detection itself still uses
      // the normal view range and occlusion tests, not the sector overlay.
      const look =
        mode === 'search' || mode === 'investigate'
          ? Math.atan2(dest.y - u.y, dest.x - u.x)
          : mode === 'survey'
            ? u.angle + 0.7 * Math.sin(now * 0.013 + b.order)
            : u.angle;
      u.setLook(look, 0);
      u.slewDriver(1 / 60);
    }
    drive(u, b, mode, dest, nav, now);
  }
  return { attach, beginTick, step, onBlockedHit };
})();
