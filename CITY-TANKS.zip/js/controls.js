function showControlModal(mode) {
  GameState.pendingBattle = mode;
  document.getElementById('control-modal').classList.add('show');
}
function selectControl(type) {
  GameState.controlMode = type;
  document.getElementById('control-modal').classList.remove('show');
  document.body.classList.toggle('mobile-mode', type === 'mobile');
  if (GameState.pendingBattle === 'train') return startTraining();
  return startBattle(GameState.pendingBattle);
}
// Track each physical pointer independently. A lifted aim finger must never release
// another finger's throttle or trigger, including on capture loss / app switching.
let lookDrag = null,
  lastPick = null,
  stickFinger = null,
  triggerFinger = null;
function resetBattleInput() {
  BattleView.resetSight();
  lookDrag = lastPick = stickFinger = triggerFinger = null;
  GameState.keys = {};
  GameState.mouseDown = GameState.mobileFireActive = false;
  GameState.joystickData = { active: false, dx: 0, dy: 0, mag: 0 };
  document.getElementById('joystick-stick').style.transform = 'translate(-50%,-50%)';
}
function setupPCControls() {
  window.addEventListener('keydown', (e) => {
    if (
      !GameState.gameActive ||
      e.target.isContentEditable ||
      /^(INPUT|TEXTAREA|SELECT)$/.test(e.target.tagName)
    )
      return;
    if (['Space', 'ArrowLeft', 'ArrowRight'].includes(e.code)) e.preventDefault();
    GameState.keys[e.code] = true;
    if (e.repeat) return;
    if (e.code === 'KeyX') CombatMechanics.deploySmokeScreen(GameState.player);
    if (e.code === 'KeyC') CombatMechanics.callArtilleryStrike(GameState.aim.x, GameState.aim.y);
    if (e.code === 'KeyF') document.getElementById('hud').classList.toggle('photo-mode');
    if (e.code === 'KeyH') {
      snd('hit');
      combatMessage('Сигнал!', '#ffd49c');
    }
    if (e.code === 'Escape') leaveBattle();
    if (/^Digit[1-3]$/.test(e.code)) setShell(Number(e.code.slice(-1)) - 1);
    if (/^Digit[4-9]$/.test(e.code)) useCons(Number(e.code.slice(-1)) - 4);
  });
  window.addEventListener('keyup', (e) => {
    GameState.keys[e.code] = false;
  });
  // Listen on the document: the canvas is replaced after context disposal. Clicking HUD
  // buttons never fires the cannon; release/cancel/blur never leaves a trigger held.
  function pick(e) {
    if (lastPick?.[0] === e.clientX && lastPick[1] === e.clientY) return;
    lastPick = [e.clientX, e.clientY];
    BattleView.pointAt(e.clientX, e.clientY);
  }
  function beginLook(e, tapAim) {
    lookDrag = { id: e.pointerId, x: e.clientX, y: e.clientY, moved: false, tapAim };
    lastPick = null;
    e.target.setPointerCapture(e.pointerId);
    if (!tapAim) BattleView.orbitSight(e.clientX, e.clientY);
  }
  function endLook(e) {
    lastPick = [e.clientX, e.clientY];
    lookDrag = null;
  }
  document.addEventListener('contextmenu', (e) => {
    if (GameState.gameActive && e.target.id === 'game') e.preventDefault();
  });
  document.addEventListener('pointermove', (e) => {
    if (!GameState.gameActive || e.target.id !== 'game') return;
    // Pointer Events report a chord (e.g. firing during a right-button drag)
    // as a move, not a second pointerdown. Only accept buttons captured on the field.
    if (
      GameState.controlMode === 'pc' &&
      e.pointerType === 'mouse' &&
      e.target.hasPointerCapture(e.pointerId)
    ) {
      if (e.buttons & 2 && !lookDrag) beginLook(e, false);
      else if (!(e.buttons & 2) && lookDrag?.id === e.pointerId) endLook(e);
      GameState.mouseDown = !!(e.buttons & 1);
    }
    if (lookDrag?.id === e.pointerId) {
      const dx = e.clientX - lookDrag.x,
        dy = e.clientY - lookDrag.y;
      if (lookDrag.tapAim && !lookDrag.moved && Math.hypot(dx, dy) < 4) return;
      lookDrag.moved = true;
      lookDrag.x = e.clientX;
      lookDrag.y = e.clientY;
      BattleView.orbitBy(dx, dy, e.clientX, e.clientY); // consumes this displacement exactly once
    } else if (GameState.controlMode === 'pc' && e.pointerType === 'mouse') pick(e);
  });
  document.addEventListener('pointerdown', (e) => {
    if (!GameState.gameActive || e.target.id !== 'game') return;
    const pc = GameState.controlMode === 'pc';
    if ((!pc && e.button === 0) || (pc && e.button === 2)) {
      if (lookDrag) return;
      beginLook(e, !pc);
    } else if (pc && e.button === 0) {
      e.target.setPointerCapture(e.pointerId);
      GameState.mouseDown = true;
      lastPick = [e.clientX, e.clientY];
      // Press may be the first event on this canvas, or the scene may have moved.
      BattleView.fireAtCursor(e.clientX, e.clientY);
    }
  });
  const up = (e) => {
    if (lookDrag?.id === e.pointerId) {
      if (e.type === 'pointerup' && lookDrag.tapAim && !lookDrag.moved && GameState.gameActive)
        BattleView.pointAt(e.clientX, e.clientY);
      endLook(e);
    }
    if (e.pointerType === 'mouse' || GameState.controlMode === 'pc') GameState.mouseDown = false;
  };
  window.addEventListener('pointerup', up);
  window.addEventListener('pointercancel', up);
  document.addEventListener('lostpointercapture', (e) => {
    if (e.target.id === 'game') up(e);
  });
  window.addEventListener('blur', resetBattleInput);
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) resetBattleInput();
  });
  document.addEventListener(
    'wheel',
    (e) => {
      if (GameState.gameActive && e.target.id === 'game') {
        e.preventDefault();
        BattleView.focusDistance(e.deltaY);
      }
    },
    { passive: false }
  );
}
function setupMobileControls() {
  const zone = document.getElementById('joystick-zone'),
    stick = document.getElementById('joystick-stick'),
    fire = document.getElementById('fire-btn');
  function steer(e) {
    const r = zone.getBoundingClientRect(),
      dx = e.clientX - r.left - r.width / 2,
      dy = e.clientY - r.top - r.height / 2;
    const length = Math.hypot(dx, dy),
      radius = r.width * 0.38,
      divisor = Math.max(radius, length);
    const j = GameState.joystickData;
    j.active = true;
    j.dx = dx / divisor;
    j.dy = dy / divisor;
    j.mag = Math.min(1, length / radius);
    stick.style.transform = `translate(calc(-50% + ${j.dx * radius}px),calc(-50% + ${j.dy * radius}px))`;
  }
  zone.onpointerdown = (e) => {
    if (!GameState.gameActive || stickFinger !== null) return;
    stickFinger = e.pointerId;
    zone.setPointerCapture(stickFinger);
    steer(e);
  };
  zone.onpointermove = (e) => {
    if (stickFinger === e.pointerId) steer(e);
  };
  zone.onlostpointercapture = (e) => {
    if (stickFinger !== e.pointerId) return;
    stickFinger = null;
    GameState.joystickData = { active: false, mag: 0, dx: 0, dy: 0 };
    stick.style.transform = 'translate(-50%,-50%)';
  };
  fire.onpointerdown = (e) => {
    if (!GameState.gameActive || triggerFinger !== null) return;
    triggerFinger = e.pointerId;
    fire.setPointerCapture(e.pointerId);
    GameState.mobileFireActive = true;
    GameState.player.fire(GameState.curShell);
  };
  fire.onlostpointercapture = (e) => {
    if (triggerFinger !== e.pointerId) return;
    triggerFinger = null;
    GameState.mobileFireActive = false;
  };
}
