// Ангар одного игрока: все изменения попадают в тот же локальный профиль, что и ресурсы.
const hangarMail = [
  {
    id: 'mail_welcome', from: 'Штаб Командования', title: 'Добро пожаловать в ангар!',
    text: 'Командир, это ваш стартовый пакет снабжения. Удачных боёв!',
    attachment: { gold: 500, silver: 50000, xp: 5000, charges: 3 }
  },
  {
    id: 'mail_event', from: 'Служба снабжения', title: 'Посылка для экипажа',
    text: 'Два заряда для контейнеров и золото на подготовку к выезду.',
    attachment: { charges: 2, gold: 200 }
  }
];

const HangarFeatures = {
  createClan(name, tag) {
    const cost = 2500;
    if (GameState.GOLD < cost) return { success: false, error: `Для создания клана нужно ${cost} 🪙` };
    const clan = { id: 'clan_' + Date.now(), name, tag: tag.toUpperCase(), emblem: '🛡️', leader: 'Командир', members: ['Командир'], level: 1 };
    GameState.GOLD -= cost;
    GameState.clans.push(clan);
    GameState.clanId = clan.id;
    GameState.clanTag = clan.tag;
    saveProgress();
    updateResources();
    return { success: true };
  },

  getMailbox() {
    return hangarMail.map(letter => ({ ...letter, claimed: GameState.claimedMail.includes(letter.id) }));
  },

  claimMailAttachment(id) {
    const letter = hangarMail.find(item => item.id === id);
    if (!letter || GameState.claimedMail.includes(id)) return false;
    const reward = letter.attachment;
    GameState.GOLD += reward.gold || 0;
    GameState.SILVER += reward.silver || 0;
    GameState.XP += reward.xp || 0;
    GameState.charges += reward.charges || 0;
    GameState.claimedMail.push(id);
    saveProgress();
    return true;
  },

  dealWorldBossDamage(damage) {
    GameState.worldBossHp = Math.max(0, GameState.worldBossHp - damage);
  },

  // 7. РЕЙТИНГОВАЯ ЛИГА (Ranked League & MMR)
  getRankLeague(rating) {
    if (rating >= 4500) return { name: '👑 Легенда', color: '#ff0055', icon: '👑' };
    if (rating >= 3500) return { name: '💎 Мастер', color: '#00e5ff', icon: '💎' };
    if (rating >= 2500) return { name: '💠 Бриллиант', color: '#3388ff', icon: '💠' };
    if (rating >= 1800) return { name: '🥇 Платина', color: '#00ffcc', icon: '🥇' };
    if (rating >= 1200) return { name: '🥈 Золото', color: '#ffd700', icon: '🥈' };
    if (rating >= 700) return { name: '🥉 Серебро', color: '#c0c0c0', icon: '🥉' };
    return { name: '🛡️ Бронза', color: '#cd7f32', icon: '🛡️' };
  },

  updateRankedMatch(won, kills, damage) {
    if (!GameState.rankedRating) GameState.rankedRating = 1000;
    const delta = won ? (25 + Math.floor(kills * 5) + Math.floor(damage / 500)) : -Math.max(5, 20 - Math.floor(damage / 800));
    GameState.rankedRating = Math.max(100, GameState.rankedRating + delta);
    return { rating: GameState.rankedRating, delta, league: this.getRankLeague(GameState.rankedRating) };
  }
};
