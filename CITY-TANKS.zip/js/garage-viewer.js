// The inspection stand is read-only. Only the carousel/research tree selects a tank for battle.
const GarageViewer = (() => {
  const el = id => document.getElementById(id);
  const classNames = { lt: 'Лёгкий танк', mt: 'Средний танк', ht: 'Тяжёлый танк', td: 'ПТ-САУ' };
  let exhibits = [], selectedId = null, inspectedId = null, frame = null;
  let inspecting = true;

  function description(tank) {
    return [CONFIG.NATIONS[tank.nat], CONFIG.TIER_ROMAN[tank.tier] + ' ур.', classNames[tank.cls]].filter(Boolean).join(' · ');
  }

  // Removing the browsing context also releases its controls, animation loop and WebGL scene.
  function suspend() {
    if (frame) frame.remove();
    frame = null;
    el('bay-poster').hidden = true;
  }

  function showStand() {
    if (!inspecting || GameState.gameActive) { suspend(); return; }
    const tank = DB[inspectedId];
    const file = tank.exhibit || tank.file;
    el('bay-kind').textContent = inspectedId === selectedId ? 'БОЕВАЯ МАШИНА' : 'ВЫСТАВОЧНЫЙ ОБРАЗЕЦ';
    el('bay-name').textContent = tank.n;
    el('bay-meta').textContent = description(tank) + (tank.mag ? ` · Пулемёт: ${tank.mag} × ${shotDamage(tank)}` : '');
    el('bay-picker').value = inspectedId;
    const open = el('bay-open');
    open.hidden = false;
    open.href = 'models/' + file;
    if (frame?.dataset.tankId === inspectedId) return;
    suspend();
    frame = document.createElement('iframe');
    frame.title = '3D-осмотр: ' + tank.n;
    frame.dataset.tankId = inspectedId;
    frame.setAttribute('sandbox', 'allow-scripts'); // The exhibit cannot read the local profile.
    frame.src = open.href + '#hangar';
    el('bay-viewport').appendChild(frame);
  }

  function setPane(inspection) {
    inspecting = inspection;
    el('bay-inspection').hidden = !inspection;
    el('bay-research').hidden = inspection;
    el('bay-inspect-tab').setAttribute('aria-pressed', String(inspection));
    el('bay-research-tab').setAttribute('aria-pressed', String(!inspection));
    if (!inspection) renderTree();
    showStand();
  }

  function inspect(id) {
    if (!DB[id]) return;
    inspectedId = id;
    setPane(true);
  }

  function updatePicker() {
    const picker = el('bay-picker');
    picker.replaceChildren(new Option('Для боя: ' + DB[selectedId].n, selectedId));
    const group = document.createElement('optgroup');
    group.label = 'Выставка 3D · без разблокировки';
    for (const id of exhibits) {
      if (id !== selectedId) group.appendChild(new Option(DB[id].n, id));
    }
    if (group.childElementCount) picker.appendChild(group);
  }

  function syncSelection(fromCarousel = false) {
    const id = GameState.selected;
    if (selectedId === null) inspectedId = id;
    else if (selectedId !== id || fromCarousel) inspectedId = id;
    if (selectedId !== id) {
      selectedId = id;
      const tank = DB[id];
      el('dispatch-name').textContent = tank.n;
      el('dispatch-meta').textContent = description(tank);
      el('dispatch-hp').textContent = tank.hp;
      el('dispatch-dmg-label').textContent = tank.mag ? 'Урон барабана' : 'Урон за выстрел';
      el('dispatch-dmg').textContent = tank.mag ? `${tank.alpha} (${tank.mag} × ${shotDamage(tank)})` : tank.alpha;
      el('dispatch-drum').hidden = !tank.mag;
      el('dispatch-reload').textContent = (tank.reload/1000).toLocaleString('ru-RU') + ' с';
      el('dispatch-pen').textContent = tank.pen + ' мм';
      el('dispatch-armor').textContent = armorLabel(tank) + ' мм';
      el('dispatch-speed').textContent = speedLabel(tank) + ' км/ч';
      el('dispatch-view').textContent = tank.vr + ' м';
      updatePicker();
    }
    el('fleet-count').textContent = String(GameState.owned.length).padStart(2, '0');
    if (fromCarousel && !inspecting) setPane(true);
    else showStand();
  }

  function init() {
    exhibits = Object.keys(DB);
    el('bay-inspect-tab').addEventListener('click', () => setPane(true));
    el('bay-research-tab').addEventListener('click', () => setPane(false));
    window.addEventListener('message', e => {
      if (!frame || e.source !== frame.contentWindow || e.data?.type !== 'city-tanks/poster' || e.data.id !== inspectedId) return;
      frame.hidden = true;
      const poster = el('bay-poster'), img = poster.querySelector('img');
      img.src = 'models/' + DB[inspectedId].thumbnail;
      img.alt = 'Снимок 3D-модели: ' + DB[inspectedId].n;
      poster.hidden = false;
    });
    el('bay-picker').addEventListener('change', event => {
      inspectedId = event.target.value;
      showStand();
    });
  }

  return { init, syncSelection, suspend, inspect };
})();
