// One save per browser. Never serialize a running match or any account credentials.
const LOCAL_SAVE_KEY = 'ct_progress_v1';
const progressFields = Object.keys(initialProgress());
let canSaveProgress = false;
let lastSavedProgress = null;

function isProgressObject(value) {
  return value !== null && typeof value === 'object' && !Array.isArray(value);
}

// Restore known fields and their types. Empty objects are inventory maps keyed by tank/item ID.
function restoreField(fallback, value) {
  if (Array.isArray(fallback)) return Array.isArray(value) ? value : fallback;
  if (isProgressObject(fallback)) {
    if (!isProgressObject(value)) return fallback;
    const keys = Object.keys(fallback);
    if (!keys.length) return value;
    return Object.fromEntries(keys.map(key => [key, restoreField(fallback[key], value[key])]));
  }
  if (typeof fallback === 'number') return Number.isFinite(value) && value >= 0 ? value : fallback;
  return typeof value === typeof fallback ? value : fallback;
}

function readLegacyProgress() {
  function read(key) {
    const raw = localStorage.getItem(key);
    try { return JSON.parse(raw); } catch { return null; }
  }
  const users = read('ct_users');
  const accounts = isProgressObject(users) ? Object.values(users) : [];
  // On shared devices don't select an account or import shared reward flags into an empty garage.
  if (accounts.length !== 1 || !isProgressObject(accounts[0]?.data)) return {};
  const data = { ...accounts[0].data };
  const clans = read('ct_clans');
  const mail = read('ct_mailbox');
  const boss = read('ct_world_boss');
  if (Array.isArray(clans)) data.clans = clans.filter(isProgressObject);
  if (Array.isArray(mail)) data.claimedMail = mail.filter(letter => letter?.claimed).map(letter => letter.id);
  if (Number.isFinite(boss?.currentHp)) data.worldBossHp = boss.currentHp;
  return data;
}

function setSaveStatus(message, warning) {
  const status = document.getElementById('save-status');
  if (status.textContent !== message) status.textContent = message;
  status.classList.toggle('warning', warning);
}

function loadProgress() {
  let raw;
  try {
    raw = localStorage.getItem(LOCAL_SAVE_KEY);
    const data = raw === null ? readLegacyProgress() : JSON.parse(raw);
    if (!isProgressObject(data)) throw new Error('Invalid save');
    const defaults = initialProgress();
    const restored = restoreField(defaults, data);
    restored.owned = [...new Set(restored.owned.filter(id => typeof id === 'string' && Object.hasOwn(DB, id)))];
    if (!restored.owned.length) restored.owned = defaults.owned;
    if (!restored.owned.includes(restored.selected)) restored.selected = restored.owned[0];
    if (!PLAYABLE_NATIONS.includes(restored.curNat)) restored.curNat = DB[restored.selected].nat;
    // Retire per-vehicle state only. Camos are keyed by skin, not tank, and stay purchased.
    for (const key of ['modules', 'upgrades', 'upgradesBought', 'equippedCamo', 'crew', 'blueprints']) {
      restored[key] = Object.fromEntries(Object.entries(restored[key]).filter(([id]) => Object.hasOwn(DB, id)));
    }
    restored.inventory = migrateSupplyBoxes(restored.inventory);
    for (const q of restored.dailyQuests.quests) {
      if (q?.type === 'kills_nation' && !PLAYABLE_NATIONS.includes(q.nation)) {
        q.nation = DB[restored.selected].nat;
        q.desc = `Уничтожь ${q.target} танков нации «${CONFIG.NATIONS[q.nation]}»`;
      }
    }
    Object.assign(GameState, restored);
    canSaveProgress = true;
    lastSavedProgress = raw;
  } catch {
    // Storage can be blocked (including for file://) or contain an unreadable save. Still allow play.
    // In particular, don't replace an unreadable save with a fresh one on the first autosave.
    canSaveProgress = false;
    setSaveStatus(raw ? 'Не удалось прочитать прогресс · без записи' : 'Хранилище недоступно · без сохранения', true);
  }
}

function saveProgress() {
  if (!canSaveProgress) return;
  try {
    const snapshot = JSON.stringify(Object.fromEntries(progressFields.map(key => [key, GameState[key]])));
    if (snapshot !== lastSavedProgress) {
      localStorage.setItem(LOCAL_SAVE_KEY, snapshot);
      lastSavedProgress = snapshot;
    }
    setSaveStatus('Сохранение в этом браузере', false);
  } catch {
    setSaveStatus('Не удалось сохранить прогресс', true);
  }
}

function startAutosave() {
  saveProgress();
  setInterval(saveProgress, 5000);
  window.addEventListener('pagehide', saveProgress);
  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') saveProgress();
  });
}
