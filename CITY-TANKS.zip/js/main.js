const minimap = document.getElementById('minimap'),
  mCtx = minimap.getContext('2d');
const TICK = 1000 / 60;
let battleFrame = 0,
  lastFrame = 0,
  accumulated = 0,
  ticks = 0;
const clamp = (n, lo, hi) => Math.max(lo, Math.min(hi, n));
const angleDiff = (to, from) => Math.atan2(Math.sin(to - from), Math.cos(to - from));

function tryDrive(u, speed, heading = u.angle) {
  const x = u.x + Math.cos(heading) * speed,
    y = u.y + Math.sin(heading) * speed;
  if (tankCollides(x, y, heading, 25 * u.s, u)) return false;
  u.x = x;
  u.y = y;
  u.isMoving = true;
  return true;
}
function driveSpeed(u) {
  return applyTerrainToSpeed(u, u.baseSpeed * (u.trackBroken ? 0.3 : 1) * getCritMultiplier(u, 'speed'));
}
function updatePlayer() {
  const g = GameState,
    p = g.player,
    joy = g.joystickData,
    pc = g.controlMode === 'pc';
  const forward = pc
    ? (g.keys.KeyW ? 1 : 0) - (g.keys.KeyS ? 0.6 : 0)
    : Math.abs(joy.dy) > 0.12
      ? -joy.dy * (joy.dy > 0 ? 0.65 : 1)
      : 0;
  const turn = pc ? (g.keys.KeyD ? 1 : 0) - (g.keys.KeyA ? 1 : 0) : Math.abs(joy.dx) > 0.12 ? joy.dx : 0;
  p.isMoving = false;
  p.angle += turn * 0.034 * getTerrainTurnMul(p);
  if (forward) tryDrive(p, forward * driveSpeed(p) * (g.fuelBoostActive ? 1.15 : 1));
  applyIceDrift(p);
  if (g.mouseDown || g.mobileFireActive) p.fire(g.curShell);
  if (p.isMoving && ++p.engineTick % 8 === 0) {
    smoke(p.x - 14 * Math.cos(p.angle), p.y - 14 * Math.sin(p.angle));
    snd('eng');
  }
}
function updateAI(u) {
  u.isMoving = false;
  if (u.practiceTarget) return;
  const hostile = (t) => !t.dead && (t.team === 'enemy') !== (u.team === 'enemy');
  let target = null,
    distance = Infinity;
  for (const t of GameState.units) {
    if (!hostile(t) || !t.spotted) continue;
    const d = Math.hypot(t.x - u.x, t.y - u.y);
    if (d < distance) {
      target = t;
      distance = d;
    }
  }
  // Columns converge toward the opposing side, but don't all drive into the same point.
  const dx = (target ? target.x : u.team === 'enemy' ? -450 : 450) - u.x;
  const dy = (target ? target.y : u.lane) - u.y;
  const desired = Math.atan2(dy, dx);
  if (target) {
    u.tAngle += clamp(angleDiff(desired, u.tAngle), -0.048, 0.048);
    u.aimPitch = Math.atan2(target.aimHeight - u.gunHeight, Math.max(1, distance));
  } else {
    u.tAngle = u.angle;
    u.aimPitch = 0;
  }
  let drive = target ? (distance > 195 ? 1 : distance < 92 ? -0.48 : 0) : 1;
  if (u.detourTicks > 0) {
    u.detourTicks--;
    drive = 1;
  }
  const travel = u.detourTicks > 0 ? u.detourHeading : desired;
  u.angle += clamp(angleDiff(travel, u.angle), -0.043, 0.043);
  if (drive && !tryDrive(u, drive * driveSpeed(u) * 0.84)) {
    if (!u.detourTicks) u.driveBias *= -1;
    u.detourHeading = u.angle + u.driveBias * 1.25;
    u.detourTicks = 26;
    tryDrive(u, driveSpeed(u) * 0.7, u.detourHeading);
  }
  if (target && distance < 540 && Math.abs(angleDiff(desired, u.tAngle)) < 0.06) {
    // Acquire once, then hold the trigger. Tank.fire owns both intra-drum cadence and reload.
    if (++u.aimTicks > 24) u.fire(0);
  } else u.aimTicks = 0;
}
function damageUnit(b, u, part) {
  const {dmg, zone} = resolveHit(b, u, part);
  if (!dmg) {
    sparks(b.x, b.y);
    snd('rico');
    if (b.shooter === GameState.player) {
      combatMessage('Не пробито: ' + (part === 'turret' ? 'башня' : 'корпус'), '#eabb70');
    }
    return;
  }
  const dealt = Math.min(u.hp, dmg);
  u.hp = Math.max(0, u.hp - dmg);
  sparksAdvanced(b.x, b.y, b.a);
  snd('hit');
  if (!u.trackBroken && Math.random() < 0.1) {
    u.trackBroken = true;
    if (u === GameState.player) combatMessage('Повреждена гусеница', '#f28b68');
  }
  if (b.shooter === GameState.player) {
    GameState.battleDmg += dealt;
    dmgLog('−' + Math.ceil(dealt) + ' · ' + CONFIG.ARMOR_ZONES[zone].label, '#ffd38a');
  }
  if (u === GameState.player) {
    dmgLog('−' + Math.ceil(dealt), '#ffa78b');
    onPlayerHit(b.a, dealt);
  }
  if (u.hp > 0) return;
  u.dead = true;
  boom(u.x, u.y);
  snd('boom');
  if (b.shooter === GameState.player) {
    GameState.XP += u.tier * 500;
    GameState.battleKills++;
    combatMessage('Цель уничтожена', '#ffe3ae');
  }
  updateScoreboard();
}
function updateBullets() {
  for (let i = GameState.bullets.length - 1; i >= 0; i--) {
    const b = GameState.bullets[i];
    const step = traceBattleRay(b.x, b.y, b.h, b.dx, b.dy, b.dh, b.speed, b.shooter);
    b.x = step.x;
    b.y = step.y;
    b.h = step.h;
    b.traveled += step.distance;
    if (step.hit instanceof Tank) damageUnit(b, step.hit, step.part);
    else if (step.hit) {
      spawnParticles(b.x, b.y, '#e2bc7b', 8, 2, 11, b.h);
      if (step.hit.type === 'building') damageWall(step.hit, b.dmg, GameState.walls.indexOf(step.hit));
    }
    if (step.hit || b.traveled >= BATTLE_RANGE) {
      GameState.bullets.splice(i, 1);
    }
  }
}
function update() {
  const g = GameState,
    p = g.player,
    now = Date.now();
  ticks++;
  if (g.adrenalineActive && now > g.adrenalineTimer) g.adrenalineActive = false;
  if (g.fuelBoostActive && now > g.fuelBoostTimer) g.fuelBoostActive = false;
  // Spot once per team, not again inside every bot's target search (20 units at 60 Hz).
  if (ticks === 1 || ticks % 6 === 0)
    for (const u of g.units) {
      u.spotted = g.training || teamSees(u, u.team === 'enemy' ? 'player' : 'enemy');
      u.visible = u.team !== 'enemy' || u.spotted;
    }
  for (const u of g.units) {
    if (u.dead) continue;
    u.updateReload(performance.now());
    u.justFired = now < u.fireTimer;
    if (u === p) updatePlayer();
    else updateAI(u);
    if (u.isMoving && ticks % 5 === 0 && g.settings.showTracks)
      g.tracks.push({ x: u.x, y: u.y, a: u.angle, s: u.s, life: 130 });
    if (u.onFire && now - u.fireDmgTimer >= 1000) {
      u.hp = Math.max(0, u.hp - Math.floor(u.maxHp * 0.02));
      u.fireDmgTimer = now;
      spawnParticles(u.x, u.y, '#ef833c', 5, 2, 10);
      if (!u.hp) {
        u.dead = true;
        boom(u.x, u.y);
        updateScoreboard();
      }
    }
  }
  updateBullets();
  CombatMechanics.update(TICK / 1000);
  WeatherEngine.updateWaterPhysics(p, TICK / 1000);
  for (const x of g.particles) {
    x.x += x.vx;
    x.y += x.vy;
    x.life--;
  }
  g.particles = g.particles.filter((x) => x.life > 0);
  g.tracks = g.tracks.filter((tr) => --tr.life > 0);
  updateCasings();
  if (p.dead || !g.units.some((u) => u.team === 'enemy' && !u.dead)) endBattle(!p.dead);
}
function updateHUD() {
  const p = GameState.player,
    g = GameState,
    ammo = document.getElementById('ammo-val');
  const hp = Math.ceil(Math.max(0, p.hp));
  document.getElementById('hp-text').textContent = `${hp} / ${p.maxHp} HP`;
  document.getElementById('hp-bar').style.width = clamp((p.hp / p.maxHp) * 100, 0, 100) + '%';
  ammo.textContent =
    (p.magSize > 1 ? `БАРАБАН ${p.curMag}/${p.magSize}` : CONFIG.SHELLS[g.curShell].name) +
    '  /  ' +
    (p.isReloading
      ? `ПЕРЕЗАРЯДКА  ${Math.max(0, (p.nextShot - performance.now()) / 1000).toFixed(1)} с`
      : 'ГОТОВ');
  const c = mCtx,
    w = minimap.width,
    h = minimap.height;
  const sx = (x) => ((x + BATTLE_AREA.x) * w) / (2 * BATTLE_AREA.x),
    sy = (y) => ((y + BATTLE_AREA.y) * h) / (2 * BATTLE_AREA.y);
  c.fillStyle = '#222e2a';
  c.fillRect(0, 0, w, h);
  c.strokeStyle = '#47554a';
  c.lineWidth = 0.6;
  for (let i = 1; i < 5; i++) {
    c.beginPath();
    c.moveTo((w * i) / 5, 0);
    c.lineTo((w * i) / 5, h);
    c.moveTo(0, (h * i) / 5);
    c.lineTo(w, (h * i) / 5);
    c.stroke();
  }
  c.fillStyle = '#6b7364';
  for (const wall of g.walls)
    if (wall.solid)
      c.fillRect(
        sx(wall.x),
        sy(wall.y),
        (wall.w * w) / (2 * BATTLE_AREA.x),
        (wall.h * h) / (2 * BATTLE_AREA.y)
      );
  for (const u of g.units) {
    if (u.dead || u === p || (u.team === 'enemy' && !u.visible)) continue;
    c.fillStyle = u.team === 'enemy' ? '#ff846f' : '#77cdba';
    c.beginPath();
    c.arc(sx(u.x), sy(u.y), 2.1, 0, 2 * Math.PI);
    c.fill();
  }
  c.save();
  c.translate(sx(p.x), sy(p.y));
  c.rotate(p.angle);
  c.fillStyle = '#ffe5a6';
  c.beginPath();
  c.moveTo(5, 0);
  c.lineTo(-3, 3);
  c.lineTo(-3, -3);
  c.closePath();
  c.fill();
  c.restore();
}
function startBattleLoop() {
  stopBattleLoop();
  lastFrame = null;
  accumulated = 0;
  ticks = 0;
  function frame(now) {
    if (!GameState.gameActive) return;
    if (!document.hidden) {
      // Use RAF timestamps for both ends. The first callback can belong to the frame
      // that started a long WebGL upload and predate performance.now() at launch.
      const dt = lastFrame === null ? TICK : clamp(now - lastFrame, 0, 150);
      BattleView.budget(dt);
      accumulated += dt;
      BattleView.syncCamera();
      BattleView.aim();
      while (accumulated >= TICK && GameState.gameActive) {
        update();
        accumulated -= TICK;
      }
      BattleView.syncCamera();
      BattleView.draw();
      updateHUD();
      countPerfFrame();
    }
    lastFrame = now;
    if (GameState.gameActive) battleFrame = requestAnimationFrame(frame);
  }
  battleFrame = requestAnimationFrame(frame);
}
function stopBattleLoop() {
  cancelAnimationFrame(battleFrame);
  battleFrame = 0;
}
function init() {
  loadProgress();
  applySettings();
  GarageViewer.init();
  updateScale();
  setupPCControls();
  setupMobileControls();
  fillTrainNatSelect();
  fillEnemySelect();
  renderTree();
  renderCarousel();
  updateResources();
  updateInvCount();
  updateBoosterUI();
  startAutosave();
}
document.addEventListener('DOMContentLoaded', init, { once: true });
