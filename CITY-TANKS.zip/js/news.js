// js/news.js
// ========== ЛЕНТА НОВОСТЕЙ В АНГАРЕ ==========
console.log('📰 news.js загружен');
// Новости поставляются вместе с игрой, без загрузки из сети.
const HANGAR_NEWS = [
  { id: 6, title: 'Первая ветка СССР: путь к ИС-7', body: 'Восемь машин получили собственные 3D-модели. Сравните характеристики в дереве развития. У Т-46 пулемёт: 60 базового урона за барабан, а не за патрон.' },
  { id: 5, title: 'МС-1 выходит на полигон', body: 'МС-1 доступен в 3D-ангаре и на поле боя.' },
  { id: 4, title: '💾 Локальный ангар', body: 'Танки, награды и настройки сохраняются в этом браузере. Для боёв с ботами интернет не нужен.' },
  { id: 3, title: '🎖️ Боевой пропуск: Сезон 1', body: '30 уровней наград, золото и контейнеры снабжения в премиум-треке.' },
  { id: 1, title: '🛡️ Боевая механика', body: 'Дифференцированное бронирование, разрушаемые здания, физика ландшафта и критические повреждения модулей.' }
];

// ========== РЕНДЕР (ожидает <div id="news-feed"></div>) ==========
function renderNewsFeed() {
  var box = document.getElementById('news-feed');
  if (!box) return;
  var news = HANGAR_NEWS;
  box.innerHTML = '';

  var maxId = 0;
  news.forEach(function (n) {
    if (n.id > maxId) maxId = n.id;
    var item = document.createElement('div');
    item.style.cssText = 'background:#1a1a1a;border-left:3px solid #f1c40f;border-radius:4px;padding:8px 12px;margin-bottom:8px';
    item.innerHTML =
      '<div style="color:#f1c40f;font-weight:bold;font-size:13px">' + n.title + '</div>' +
      '<div style="color:#ccc;font-size:12px">' + n.body + '</div>';
    box.appendChild(item);
  });

  GameState.newsLastSeenId = maxId;
  saveProgress();
  updateNewsBadge(0);
}

// ========== ЗНАЧОК НЕПРОЧИТАННЫХ (вызывать при входе в ангар) ==========
function checkUnreadNews() {
  var news = HANGAR_NEWS;
  var unread = news.filter(n => n.id > GameState.newsLastSeenId).length;
  updateNewsBadge(unread);
  return unread;
}

function updateNewsBadge(count) {
  var badge = document.getElementById('news-badge');
  if (!badge) return;
  if (count > 0) { badge.style.display = 'inline-block'; badge.innerText = count; }
  else badge.style.display = 'none';
}

window.renderNewsFeed = renderNewsFeed;
window.checkUnreadNews = checkUnreadNews;
