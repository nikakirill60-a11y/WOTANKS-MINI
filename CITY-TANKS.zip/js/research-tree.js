// The original research interaction: a node per vehicle, a line from its
// prerequisite, and one click to research/select. A locked node is read-only.
let treeCardId = null,
  lastTreeSelection = null;
const treeEl = (id) => document.getElementById(id);
const xpLabel = (n) => n.toLocaleString('ru-RU') + ' XP';

// A buyback is twice the normal research vehicle's resale price; free roots stay free.
const buybackCost = t => t.xp ? t.tier * 10000 : 0;
const silverLabel = n => n.toLocaleString('ru-RU')+' ₽';
function researchState(id) {
  const t = DB[id],
    parent = researchParent(id);
  if (GameState.owned.includes(id))
    return { kind: 'owned', text: id === GameState.selected ? 'Выбран для боя' : 'В ангаре' };
  if (GameState.researched.includes(id)) {
    const cost=buybackCost(t), price=cost ? silverLabel(cost) : 'бесплатно';
    const full=HangarSlots.free()<=0, short=GameState.SILVER<cost;
    return {kind:full || short ? 'locked' : 'available',buyback:true,full,price,
      text:'Исследован · выкуп: '+price+(full ? '. '+HangarSlots.fullMessage() : short ? '. Не хватает '+silverLabel(cost-GameState.SILVER) : '')};
  }
  if (parent && !GameState.researched.includes(parent) && !GameState.owned.includes(parent))
    return { kind: 'locked', text: 'Сначала исследуйте ' + DB[parent].n };
  if (HangarSlots.free() <= 0) return { kind: 'locked', full: true, text: HangarSlots.fullMessage() };
  if (t.xp === 0)
    return { kind: 'available', text: 'Стартовая машина · нажмите узел, чтобы получить бесплатно' };
  if (GameState.XP < t.xp) return { kind: 'locked', text: 'Не хватает ' + xpLabel(t.xp - GameState.XP) };
  return { kind: 'available', text: 'Доступно исследование за ' + xpLabel(t.xp) };
}

function showTreeCard(id) {
  treeCardId = id;
  const t = DB[id];
  setVehicleCardArt(treeEl('tree-photo'), t);
  treeEl('tree-tier').textContent = CONFIG.TIER_ROMAN[t.tier] + ' · ' + CONFIG.TANK_CLASSES[t.cls];
  treeEl('tree-name').textContent = t.n;
  treeEl('tree-status').textContent = researchState(id).text;
  const stats = [
    ['Прочность', t.hp + ' HP'],
    [damageLabel(t), damageSummary(t)],
    [reloadLabel(t), (t.reload / 1000).toLocaleString('ru-RU') + ' с'],
    ['Пробитие', t.pen + ' мм'],
    ['Лоб корпуса / башни', armorLabel(t) + ' мм'],
    ['Скорость', speedLabel(t) + ' км/ч']
  ];
  if (t.mag) stats.push(['Между выстрелами', clipLabel(t)]);
  if (t.weapon === 'calibration') stats.push(['Особенность', KPZ_CALIBRATION.name]);
  if (t.cls === 'spg') stats.push(['Особенность', 'Арт-прицел · вид сверху']);
  if (t.yawLimits) {
    const [right, left] = t.yawLimits;
    stats.push([
      'Поворот орудия',
      !left && !right
        ? 'Вместе с корпусом'
        : left === -right
          ? `±${left}° от корпуса`
          : `${left}° влево · ${-right}° вправо`
    ]);
  }
  treeEl('tree-stats').replaceChildren(
    ...stats.map(([label, value]) => {
      const cell = document.createElement('div'),
        dt = document.createElement('dt'),
        dd = document.createElement('dd');
      dt.textContent = label;
      dd.textContent = value;
      cell.append(dt, dd);
      return cell;
    })
  );
}

function researchTank(id) {
  if (!Object.hasOwn(DB, id) || DB[id].source) return;
  const state = researchState(id);
  showTreeCard(id);
  if (state.kind === 'locked') return;
  if (state.kind === 'available') {
    if (!HangarSlots.park(id)) return;
    if (state.buyback) GameState.SILVER -= buybackCost(DB[id]);
    else { GameState.XP -= DB[id].xp; GameState.researched.push(id); }
  }
  GameState.selected = id;
  saveProgress();
  renderCarousel();
  updateResources();
}

function revealTreeNode() {
  const scroller = treeEl('tree-container'),
    node = treeEl('nodes').querySelector(`[data-tank-id="${treeCardId || GameState.selected}"]`);
  if (node) scroller.scrollLeft = node.offsetLeft - (scroller.clientWidth - node.offsetWidth) / 2;
  updateTreeNav();
}
function updateTreeNav() {
  const el = treeEl('tree-container');
  treeEl('tree-prev').disabled = el.scrollLeft < 1;
  treeEl('tree-next').disabled = el.scrollLeft + el.clientWidth >= el.scrollWidth - 1;
}

// Presentation only: zoom in on one supplied route without changing the
// player's tank, progression or the shared vehicle records at a fork.
function visibleRoute(branch) {
  const picker = treeEl('tree-route');
  if (picker.dataset.nation !== GameState.curNat) {
    picker.dataset.nation = GameState.curNat;
    picker.replaceChildren(new Option('Все ветки', ''), ...branch.routes.map(route => {
      const end = route.at(-1);
      return new Option(end.n, end.id);
    }));
    treeEl('route-filter').hidden = branch.routes.length < 2;
    picker.onchange = () => {
      treeCardId = picker.value || GameState.selected;
      renderTree();
      revealTreeNode();
    };
  }
  const route = branch.routes.find(r => r.at(-1).id === picker.value);
  const selected = DB[GameState.selected];
  if (route && lastTreeSelection !== GameState.selected && branch.tanks.includes(selected) && !route.includes(selected)) {
    picker.value = ''; // A newly equipped tank from another lane must not be hidden.
    return;
  }
  return route;
}

function renderTree() {
  renderNatButtons();
  const container = treeEl('tree-container'),
    nodes = treeEl('nodes'),
    canvas = treeEl('tree-canvas');
  const branch = BRANCHES[GameState.curNat],
    route = visibleRoute(branch),
    routes = route ? [route] : branch.routes,
    line = route || branch.tanks;
  treeEl('branch-number').textContent = branch.number;
  treeEl('branch-title').textContent = route ? 'Путь к танку: ' + route.at(-1).n : branch.title;
  const height = 84,
    gap = 36,
    inset = 22,
    firstRow = 36,
    rowStep = height + 18,
    mapHeight = firstRow + (routes.length - 1) * rowStep + height + 17;
  container.style.setProperty('--tree-height', mapHeight + 9 + 'px');
  const ctx = canvas.getContext('2d');
  ctx.font = getComputedStyle(nodes).getPropertyValue('--node-name-font').trim();
  // Long tier VIII–X names should not push tier II off a small phone screen.
  const tiers = Math.max(...routes.map(lane => lane.length)); // a short leaf can share the graph with full routes
  const columns = Array.from({length: tiers}, (_, i) => ({
    width: Math.max(
      137,
      ...line.filter((v) => v.tier === i + 1).map((v) => Math.ceil(ctx.measureText(v.n).width) + 20)
    )
  }));
  let nextX = inset;
  for (const col of columns) {
    col.x = nextX;
    nextX += col.width + gap;
  }
  const mapWidth = nextX - gap + inset;
  const map = treeEl('tree-map');
  map.style.width = mapWidth + 'px';
  map.style.height = mapHeight + 'px';
  const dpr = Math.min(window.devicePixelRatio || 1, 2);
  canvas.width = Math.round(mapWidth * dpr);
  canvas.height = Math.round(mapHeight * dpr);
  canvas.style.width = mapWidth + 'px';
  canvas.style.height = mapHeight + 'px';
  ctx.scale(dpr, dpr);
  // Routes sharing a prefix are adjacent in the catalogue. Draw each shared
  // node once, centred over the lanes that descend from it, including later forks.
  const pos = new Map();
  for (const t of line) {
    const lanes = routes.flatMap((lane, i) => (lane[t.tier - 1] === t ? [i] : []));
    const y = firstRow + (lanes[0] + lanes.at(-1)) * rowStep / 2;
    pos.set(t.id, { ...columns[t.tier - 1], y });
  }
  ctx.font = '11px Consolas, monospace';
  ctx.textAlign = 'center';
  ctx.fillStyle = '#acb6ab';
  columns.forEach(({ x, width }, i) => ctx.fillText(CONFIG.TIER_ROMAN[i + 1], x + width / 2, 24));
  const focused = nodes.contains(document.activeElement) && document.activeElement.dataset.tankId;
  const buttons = line.map((t) => {
    const { id } = t,
      { x, y, width } = pos.get(id),
      state = researchState(id),
      selected = GameState.selected === id;
    const parent = pos.get(researchParent(id));
    if (parent) {
      ctx.strokeStyle =
        state.kind === 'owned' ? '#87ac82' : state.kind === 'available' ? '#c8b181' : '#66726a';
      ctx.lineWidth = 2;
      ctx.beginPath();
      ctx.moveTo(parent.x + parent.width, parent.y + height / 2);
      ctx.lineTo(x, y + height / 2);
      ctx.stroke();
    }
    const button = document.createElement('button');
    button.type = 'button';
    button.className = `node ${state.kind}${selected ? ' selected' : ''}`;
    button.dataset.tankId = id;
    Object.assign(button.style, {
      left: x + 'px',
      top: y + 'px',
      width: width + 'px',
      height: height + 'px'
    });
    const action =
      state.kind === 'owned' ? 'Выбрать' : state.kind === 'available' ? (state.buyback ? 'Выкупить' : 'Исследовать') : 'Характеристики';
    button.setAttribute('aria-label', action + ': ' + t.n);
    button.setAttribute('aria-pressed', String(selected));
    button.title = t.n + ' · ' + state.text;
    button.setAttribute('aria-description', state.text);
    const tag = document.createElement('small'),
      name = document.createElement('b'),
      price = document.createElement('span');
    tag.textContent = CONFIG.TIER_ROMAN[t.tier] + ' / ' + CONFIG.TANK_CLASSES[t.cls];
    name.textContent = t.n;
    price.textContent = selected
      ? '✓ Для боя'
      : state.kind === 'owned'
        ? 'В ангаре'
        : state.buyback ? 'Исследован · '+state.price : state.full ? 'Нет места' : t.xp
          ? xpLabel(t.xp)
          : 'Бесплатно';
    const img = document.createElement('img');
    img.alt = '';
    img.className = 'node-tank';
    img.draggable = false;
    button.append(tag, img, name, price);
    setVehicleCardArt(img, t);
    button.onfocus = () => showTreeCard(id);
    button.onpointerenter = (e) => {
      if (e.pointerType === 'mouse') showTreeCard(id);
    };
    button.onclick = () => researchTank(id);
    return button;
  });
  nodes.replaceChildren(...buttons);
  // Browsing a nation does not equip its tank. A branch always opens on a card belonging to it.
  if (!line.includes(DB[treeCardId]) || lastTreeSelection !== GameState.selected) {
    treeCardId =
      line.includes(DB[GameState.selected])
        ? GameState.selected
        : line.filter((t) => GameState.owned.includes(t.id)).sort((a, b) => b.tier - a.tier)[0]?.id ||
          line[0].id;
  }
  lastTreeSelection = GameState.selected;
  showTreeCard(treeCardId || GameState.selected);
  if (focused) buttons.find((b) => b.dataset.tankId === focused)?.focus({ preventScroll: true });
  container.onscroll = updateTreeNav;
  for (const [key, sign] of [
    ['prev', -1],
    ['next', 1]
  ])
    treeEl('tree-' + key).onclick = () => {
      container.scrollBy({
        left: sign * Math.max(columns[0].width + gap, container.clientWidth - columns[0].width - gap),
        behavior: 'instant'
      });
      updateTreeNav();
    };
  updateTreeNav();
}
window.addEventListener('resize', () => {
  if (!treeEl('bay-research').hidden) revealTreeNode();
});
