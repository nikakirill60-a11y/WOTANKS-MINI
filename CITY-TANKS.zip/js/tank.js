// js/tank.js
// ========== КЛАСС ТАНКА ==========

class Tank {
  constructor(id, x, y, team, allBonuses) {
    var d = DB[id];
    this.id = id;
    this.name = d.n;
    this.team = team;
    this.x = x;
    this.y = y;

    var mb = allBonuses ? allBonuses.mod || {} : {};
    var ub = allBonuses ? allBonuses.upg || {} : {};

    var hpMul = ub.hpMul || 1;
    var dmgMul = ub.dmgMul || 1;
    var reloadMul = ub.reloadMul || 1;
    var speedMul = ub.speedMul || 1;
    var vrMul = ub.vrMul || 1;

    this.hp = Math.floor(d.hp * hpMul * (1 + (mb.hp || 0)));
    this.maxHp = this.hp;
    this.dmg = Math.floor(shotDamage(d) * dmgMul * (1 + (mb.dmg || 0)));
    this.s = d.s;
    this.tier = d.tier;
    var eagleEyeBonus =
      team === 'player' && typeof getCrewPerkValue === 'function' ? getCrewPerkValue(id, 'commander', 'vr') : 0;
    this.vr = Math.floor((d.vr || 350) * vrMul * (1 + (mb.vr || 0) + eagleEyeBonus));
    var camoSkinBonus = 0;
    if (
      team === 'player' &&
      typeof GameState !== 'undefined' &&
      GameState.equippedCamo &&
      GameState.equippedCamo[id]
    ) {
      var skinId = GameState.equippedCamo[id];
      var skin = CONFIG.CAMOS && CONFIG.CAMOS[skinId];
      if (skin) camoSkinBonus = skin.camoBonus;
    }
    this.camo = (d.camo || 0.2) * (1 + (mb.camo || 0)) + camoSkinBonus;
    this.armor = Math.floor((d.armor || 0) * (1 + (mb.armor || 0)));

    this.turretArmor = Math.floor(d.turretArmor * (1 + (mb.armor || 0)));
    this.pen = d.pen;

    // ✅ Критические повреждения модулей (см. armor-system.js)
    this.critTimers = { engine: 0, ammo: 0, gunner: 0 };
    // ✅ Экипаж (см. crew.js) — бонусы перков применяются точечно через getCrewBonus()
    this.crewTankId = id;

    this.angle = 0;
    this.tAngle = 0;
    this.lastShot = 0;
    this.dead = false;
    this.isMachineGun = d.weapon === 'machinegun';
    this.magSize = d.mag || 1;
    this.curMag = this.magSize;
    this.isReloading = false;
    this.reloadTime = Math.floor((d.reload || 2500) * reloadMul * (1 + (mb.reload || 0)));
    // km/h → metres/s → world units per 60-Hz simulation step.
    this.baseSpeed = (d.speed / 3.6) * BATTLE_UNITS_PER_METRE / 60 * speedMul * (1 + (mb.speed || 0));
    this.isMoving = false;
    this.justFired = false;
    this.fireTimer = 0;
    this.trackBroken = false;
    this.visible = true;
    this.engineTick = 0;
    this.shotDelay = d.shotDelay || 0;

    this.aimPitch = 0;
    this.modelScale = BATTLE_UNITS_PER_METRE;
    this.shellSpeedMul = 1 + (mb.shell_speed || 0);
    this.onFire = false;
    this.fireDmgTimer = 0;
    this.nextShot = 0;
    this.driveBias = Math.random() < 0.5 ? -1 : 1;
  }

  updateReload(now) {
    if (this.isReloading && now >= this.nextShot) {
      this.curMag = this.magSize;
      this.isReloading = false;
    }
  }

  fire(shellType = 0) {
    const now = performance.now();
    this.updateReload(now);
    if (this.dead || this.isReloading || now < this.nextShot || !this.modelAsset) return false;
    if (this.isMachineGun) shellType = 0; // One belt type, including for AI and touch input.
    const sh = CONFIG.SHELLS[shellType],
      muzzle = this.muzzle();
    const speed = 14 * sh.sMul * this.shellSpeedMul;
    const horizontal = Math.cos(this.aimPitch);
    const damage = this.dmg * sh.dMul * getCritMultiplier(this, 'dmg');
    GameState.bullets.push({
      ...muzzle,
      a: this.tAngle,
      team: this.team,
      shooter: this,
      dx: Math.cos(this.tAngle) * horizontal,
      dy: Math.sin(this.tAngle) * horizontal,
      dh: Math.sin(this.aimPitch),
      speed,
      traveled: 0,
      color: sh.color,
      dmg: damage * (this === GameState.player && GameState.paiokActive ? 1.05 : 1),
      pen: this.pen * sh.penMul,
      st: shellType
    });
    this.lastShot = Date.now();
    this.justFired = true;
    this.fireTimer = this.lastShot + 3000;
    this.curMag--;
    const multiplier =
      (this === GameState.player && GameState.adrenalineActive ? 0.5 : 1) * getCritMultiplier(this, 'reload');
    this.nextShot = now + (this.curMag ? this.shotDelay : this.reloadTime * multiplier);
    this.isReloading = !this.curMag;
    spawnParticles(muzzle.x, muzzle.y, '#ffb24c', 5, 1.2, 8, muzzle.h);
    spawnShellCasing(this);
    snd(this.isMachineGun ? 'rapidfire' : 'shot');
    return true;
  }

  get aimHeight() { return this.modelAsset.aimHeight * this.modelScale; }
  get gunHeight() { return (this.modelAsset.groundY + this.modelAsset.pivot[1] + this.modelAsset.gunPivot[1]) * this.modelScale; }

  // Same hull → turret → gun transforms as the renderer, in simulation coordinates (x,y,height).
  muzzle() {
    const { pivot, gunPivot, muzzle } = this.modelAsset,
      s = this.modelScale;
    const side = gunPivot[0] + muzzle[0];
    const forward = gunPivot[2] + muzzle[2] * Math.cos(this.aimPitch) - muzzle[1] * Math.sin(this.aimPitch);
    return {
      x:
        this.x +
        s *
          (pivot[2] * Math.cos(this.angle) +
            pivot[0] * Math.sin(this.angle) +
            forward * Math.cos(this.tAngle) +
            side * Math.sin(this.tAngle)),
      y:
        this.y +
        s *
          (pivot[2] * Math.sin(this.angle) -
            pivot[0] * Math.cos(this.angle) +
            forward * Math.sin(this.tAngle) -
            side * Math.cos(this.tAngle)),
      h:
        s *
        (this.modelAsset.groundY +
          pivot[1] +
          gunPivot[1] +
          muzzle[1] * Math.cos(this.aimPitch) +
          muzzle[2] * Math.sin(this.aimPitch))
    };
  }
}

function canSee(obs, tgt) {
  if (obs === tgt || tgt.dead) return true;
  var d = Math.hypot(obs.x - tgt.x, obs.y - tgt.y);
  var er = (obs.vr || 350) * (1 - (tgt.camo || 0.2) * 0.7);
  if (tgt.isMoving) er *= 1.3;
  if (tgt.justFired) er *= 1.5;
  if (d > er) return false;
  if (d < 1) return true;
  const h = obs.gunHeight,
    dz = tgt.aimHeight - h,
    length = Math.hypot(d, dz);
  return !traceBattleRay(
    obs.x,
    obs.y,
    h,
    (tgt.x - obs.x) / length,
    (tgt.y - obs.y) / length,
    dz / length,
    length,
    obs,
    true
  ).hit;
}

function teamSees(tgt, team) {
  for (var i = 0; i < GameState.units.length; i++) {
    var u = GameState.units[i];
    if (u.dead) continue;
    var st = team === 'enemy' ? u.team === 'enemy' : u.team !== 'enemy';
    if (st && canSee(u, tgt)) return true;
  }
  return false;
}

// ========== ПРОВЕРКА СТОЛКНОВЕНИЙ ==========
function tankCollides(x, y, angle, size, self) {
  if (Math.abs(x) + size > BATTLE_AREA.x || Math.abs(y) + size > BATTLE_AREA.y) return true;
  if (
    GameState.units.some(
      (u) => u !== self && !u.dead && Math.hypot(x - u.x, y - u.y) < (u.s * 25 + size) * 0.73
    )
  )
    return true;
  var pts = [
    { dx: 0, dy: 0 },
    { dx: size, dy: 0 },
    { dx: -size * 0.8, dy: 0 },
    { dx: size * 0.6, dy: size * 0.5 },
    { dx: size * 0.6, dy: -size * 0.5 },
    { dx: -size * 0.6, dy: size * 0.5 },
    { dx: -size * 0.6, dy: -size * 0.5 }
  ];

  for (var pi = 0; pi < pts.length; pi++) {
    var p = pts[pi];
    var rx = x + p.dx * Math.cos(angle) - p.dy * Math.sin(angle);
    var ry = y + p.dx * Math.sin(angle) + p.dy * Math.cos(angle);

    for (var wi = 0; wi < GameState.walls.length; wi++) {
      var w = GameState.walls[wi];
      if (!w.solid) continue;
      if (rx > w.x - 5 && rx < w.x + w.w + 5 && ry > w.y - 5 && ry < w.y + w.h + 5) {
        return true;
      }
    }
  }
  return false;
}

console.log('✅ tank.js загружен');
