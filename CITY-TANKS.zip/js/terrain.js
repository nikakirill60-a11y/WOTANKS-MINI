// js/terrain.js
// ========== ФИЗИКА ЛАНДШАФТА ==========
console.log('🏞️ terrain.js загружен');

// ========== ГЕНЕРАЦИЯ ЗОН ==========
function setupTerrain(mapType) {
  GameState.terrainZones = [];

  if (mapType === 'city') {
    // Асфальтовые дороги между кварталами домов (полосы по сетке)
    for (const x of [-700,-280,260,720]) GameState.terrainZones.push({x:x-44,y:-800,w:88,h:1600,type:'asphalt'});
    GameState.terrainZones.push({x:-1050,y:-64,w:2100,h:128,type:'asphalt'});
  }

  if (mapType === 'field') {
    // Грязь после дождя + пара ледяных луж
    for (let i = 0; i < 5; i++) {
      GameState.terrainZones.push({
        x: -1000 + Math.random() * 2200, y: -900 + Math.random() * 1800,
        w: 200 + Math.random() * 220, h: 150 + Math.random() * 180, type: 'mud'
      });
    }
    for (let i = 0; i < 2; i++) {
      GameState.terrainZones.push({
        x: -800 + Math.random() * 1800, y: -700 + Math.random() * 1400,
        w: 150 + Math.random() * 100, h: 120 + Math.random() * 80, type: 'ice'
      });
    }
  }

  if (mapType === 'desert') {
    // Редкий влажный оазис-грязь у дюн
    for (let i = 0; i < 3; i++) {
      GameState.terrainZones.push({
        x: -500 + Math.random() * 1600, y: -500 + Math.random() * 1000,
        w: 120 + Math.random() * 100, h: 100 + Math.random() * 80, type: 'mud'
      });
    }
  }
}

// ========== ОПРЕДЕЛЕНИЕ ТИПА ПОД ТАНКОМ ==========
function getTerrainAt(x, y) {
  var zones = GameState.terrainZones || [];
  for (var i = 0; i < zones.length; i++) {
    var z = zones[i];
    if (x > z.x && x < z.x + z.w && y > z.y && y < z.y + z.h) return z.type;
  }
  return 'normal';
}

function getTankTerrainRes(tank) {
  if (tank && tank.team === 'player' && typeof getCrewPerkValue === 'function') {
    return getCrewPerkValue(tank.crewTankId, 'driver', 'terrainRes') || 0;
  }
  return 0;
}

// ========== ВЛИЯНИЕ НА СКОРОСТЬ ==========
function applyTerrainToSpeed(tank, speed) {
  var type = getTerrainAt(tank.x, tank.y);
  tank.currentTerrain = type;
  if (type === 'normal') return speed;
  if (type === 'asphalt') {
    const spec = DB[tank.id];
    return speed * (spec.roadSpeed || spec.speed) / spec.speed;
  }

  var t = CONFIG.TERRAIN[type];
  var res = getTankTerrainRes(tank); // перк "Король бездорожья" смягчает штраф
  var mul = t.speedMul;
  if (mul < 1) mul = 1 - (1 - mul) * (1 - res);
  return speed * mul;
}

function getTerrainTurnMul(tank) {
  var type = getTerrainAt(tank.x, tank.y);
  return (CONFIG.TERRAIN[type] || CONFIG.TERRAIN.normal).turnMul;
}

// ========== ЗАНОС НА ЛЬДУ ==========
function applyIceDrift(tank) {
  if (!tank.isMoving) return;
  var type = getTerrainAt(tank.x, tank.y);
  if (type !== 'ice') return;
  var t = CONFIG.TERRAIN.ice;
  var res = getTankTerrainRes(tank);
  var drift = t.drift * (1 - res);
  tank.angle += (Math.random() - 0.5) * drift * 0.15;
}
