// js/tutorial.js
// ========== ИНТЕРАКТИВНОЕ ОБУЧЕНИЕ ==========
console.log('🎓 tutorial.js загружен');

var TUTORIAL_STEPS = [
  { id: 'move', text: '🕹️ Используйте <b>W A S D</b>, чтобы двигать танк.', check: function () { return GameState.keys['KeyW'] || GameState.keys['KeyS'] || GameState.keys['KeyA'] || GameState.keys['KeyD']; } },
  { id: 'aim', text: '🎯 Наведите прицел на вражеский танк мышью.', check: function () { return true; }, timed: 2500 },
  { id: 'fire', text: '🔫 Зажмите <b>ЛКМ</b>, чтобы выстрелить.', check: function () { return GameState.player.lastShot > 0; } },
  { id: 'shell', text: '💣 Нажмите <b>1</b>, <b>2</b> или <b>3</b>, чтобы сменить тип снаряда.', check: function () { return GameState.curShell !== tutorialStartingShell; } },
  { id: 'cons', text: '🧰 Нажмите <b>4-9</b>, чтобы использовать расходник (например, аптечку).', check: function () { return GameState.consumables.some(Boolean); } },
  { id: 'kill', text: '💥 Уничтожьте тренировочный танк противника!' }
];

var tutorialStepIndex = 0;
var tutorialTimer = null;
var tutorialPollHandle = null;

var tutorialStartingShell = 0;

async function startTutorial() {
  tutorialStepIndex = 0;
  tutorialStartingShell = GameState.curShell;
  GameState.controlMode = 'pc';
  document.body.classList.remove('mobile-mode');
  if (!await startTraining()) return;

  var overlay = document.getElementById('tutorial-overlay');
  if (overlay) overlay.style.display = 'flex';
  showTutorialStep();

  tutorialPollHandle = setInterval(pollTutorialStep, 300);
}

function showTutorialStep() {
  var step = TUTORIAL_STEPS[tutorialStepIndex];
  var box = document.getElementById('tutorial-text');
  if (box) box.innerHTML = step.text;
  if (step.timed) {
    clearTimeout(tutorialTimer);
    tutorialTimer = setTimeout(nextTutorialStep, step.timed);
  }
}

function pollTutorialStep() {
  if (!GameState.gameActive) {
    // Бой завершён. Оставляем штатный экран результатов, не перекрывая его обучением.
    closeTutorial();
    return;
  }
  var step = TUTORIAL_STEPS[tutorialStepIndex];
  if (!step || step.timed) return;
  if (step.check && step.check()) nextTutorialStep();
}

function nextTutorialStep() {
  tutorialStepIndex = Math.min(tutorialStepIndex + 1, TUTORIAL_STEPS.length - 1);
  showTutorialStep();
}

function closeTutorial() {
  clearInterval(tutorialPollHandle);
  clearTimeout(tutorialTimer);
  document.getElementById('tutorial-overlay').style.display = 'none';
  GameState.tutorialDone = true;
  saveProgress();
}

function skipTutorial() {
  closeTutorial();
  backToGarage();
}
