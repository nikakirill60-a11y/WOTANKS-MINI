// Soviet line 01. Alpha is the TOTAL base damage of one load, not damage per bullet.
// A row without a model is informational: it never enters DB, saves, rewards or a battle.
const USSR_BRANCH = (() => {
  const tank = (id, n, tier, cls, model, hp, alpha, reload, pen, armor, turretArmor, speed, extras = {}) =>
    Object.freeze({id, n, tier, cls, nat:'ussr', hp, alpha, reload, pen, armor, turretArmor, speed,
      ...(model ? {file: model + '-game.html', thumbnail: model + '.webp'} : {}), ...extras});
  //                                               HP   alpha   ms   pen  hull turret km/h
  return Object.freeze([
    tank('MS1', 'МС-1', 1, 'lt', 'ms-1',            120,  40,  2500,  40,  16,  16, 22,
      {xp:0, s:.65, vr:270, camo:.33}),
    tank('T26', 'Т-26', 2, 'lt', 't-26',            180,  50,  2600,  55,  15,  15, 30,
      {xp:150, s:.72, vr:280, camo:.32}),
    tank('T46', 'Т-46', 3, 'lt', 't-46',            260,  60,  2800,  65,  15,  15, 45,
      {xp:350, s:.83, vr:300, camo:.30, weapon:'machinegun', mag:6, shotDelay:120}),
    // Do not mistake a legacy US tank destroyer (save ID T28) for this Soviet medium.
    tank('T28_USSR', 'Т-28', 4, 'mt', 't-28',       420, 115,  4200,  95,  30,  30, 37,
      {xp:1500, s:1.03, vr:330, camo:.24}),
    tank('KV1', 'КВ-1', 5, 'ht', 'kv-1',            700, 160,  5500, 120,  75,  75, 34,
      {xp:4000, s:1, vr:310, camo:.15}),
    tank('KV1S', 'КВ-1С', 6, 'ht', 'kv-1s',         950, 200,  6500, 145,  75,  82, 42,
      {xp:8000, s:1, vr:320, camo:.12}),
    tank('IS', 'ИС', 7, 'ht', 'is',                1300, 390, 11500, 175, 120, 100, 34,
      {xp:25000, s:1.04, vr:340, camo:.10}),
    tank('IS3', 'ИС-3', 8, 'ht', 'is-3',            1600, 390, 11000, 225, 110, 220, 38,
      {xp:60000, s:1.06, vr:350, camo:.08, markedHull:true}),
    tank('OBJ257', 'Объект 257', 9, 'ht', 'object-257', 1950, 440, 11500, 248, 140, 300, 45,
      {xp:120000, s:1.04, vr:370, camo:.08, markedHull:true}),
    tank('IS7', 'ИС-7', 10, 'ht', 'is-7',          2400, 490, 12000, 260, 150, 240, 55,
      {xp:195000, s:1.1, vr:400, camo:.06, roadSpeed:59, markedHull:true, markedTurret:true})
  ]);
})();
const DB = Object.freeze(Object.fromEntries(USSR_BRANCH.filter(t => t.file).map(t => [t.id, t])));
const STARTER_TANK = 'MS1';
const PLAYABLE_NATIONS = [...new Set(Object.values(DB).map(t => t.nat))];
const shotDamage = t => t.alpha / (t.mag || 1);
const armorLabel = t => `${t.armor}${t.markedHull ? '*' : ''} / ${t.turretArmor}${t.markedTurret ? '*' : ''}`;
const speedLabel = t => t.roadSpeed ? `${t.speed}–${t.roadSpeed}` : String(t.speed);
// The preceding tier of this line is the research prerequisite.
const researchParent = id => USSR_BRANCH.find(t => t.tier === DB[id].tier - 1)?.id;
