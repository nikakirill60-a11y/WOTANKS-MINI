// Each route starts at I and ends at its last supplied tier; forks reuse their entire shared prefix. Alpha is the TOTAL
// damage of a full load; mag counts sequential rounds, salvo counts simultaneous barrels.
const RESEARCH_XP = Object.freeze([0,150,350,1500,4000,8000,25000,60000,120000,195000]);
function defineLine(nat, rows, prefix = []) {
  const line = [...prefix];
  for (const [id,n,cls,model,hp,alpha,reload,pen,armor,turretArmor,speed,s,vr,camo,extra] of rows) {
    const i = line.length;
    line.push(Object.freeze({id,n,nat,tier:i+1,parent:line[i-1]?.id,cls,xp:RESEARCH_XP[i],
      file:model+'.mesh.js',thumbnail:model+'.webp',hp,alpha,reload,pen,armor,turretArmor,speed,s,vr,camo,...extra}));
  }
  return Object.freeze(line);
}
const USSR_BRANCH = defineLine('ussr', [
  // ID, name, class, model · HP, full alpha, reload ms, pen, hull, turret, km/h · arcade size, vision, camo
  ['MS1','МС-1','lt','ms-1',             120, 40, 2500, 40, 16, 16,22,  .65,270,.33],
  ['T26','Т-26','lt','t-26',             180, 50, 2600, 55, 15, 15,30,  .72,280,.32],
  ['T46','Т-46','lt','t-46',             260, 60, 2800, 65, 15, 15,45,  .83,300,.30,{weapon:'machinegun',mag:6,clipMs:350}],
  // T28 is an unrelated US vehicle in old saves.
  ['T28_USSR','Т-28','mt','t-28',       420,115, 4200, 95, 30, 30,37, 1.03,330,.24],
  ['KV1','КВ-1','ht','kv-1',            700,160, 5500,120, 75, 75,34,    1,310,.15],
  ['KV1S','КВ-1С','ht','kv-1s',         950,200, 6500,145, 75, 82,42,    1,320,.12],
  ['IS','ИС','ht','is',                 1300,390,11500,175,120,100,34, 1.04,340,.10],
  ['IS3','ИС-3','ht','is-3',            1600,390,11000,225,110,220,38, 1.06,350,.08,{markedHull:true}],
  ['OBJ257','Объект 257','ht','object-257',1950,440,11500,248,140,300,45,1.04,370,.08,{markedHull:true}],
  ['IS7','ИС-7','ht','is-7',            2400,490,12000,260,150,240,55, 1.10,400,.06,{roadSpeed:59,markedHull:true,markedTurret:true}]
]);
// The second heavy line forks at KV-1 (V). I–V are the original vehicle records,
// so a researched KV-1 unlocks either VI without duplicating a purchase or save ID.
const USSR_IS4_BRANCH = defineLine('ussr', [
  ['T150','Т-150','ht','t-150',1050,300, 9200,167, 90,100,35,1.02,320,.12,{minPitch:-20,maxPitch:7}],
  ['KV3','КВ-3','ht','kv-3',   1420,390,11200,175,120,130,32,1.08,320,.08,{minPitch:-24,maxPitch:7}],
  ['KV4','КВ-4','ht','kv-4',   1750,320, 8600,227,180,180,30,1.13,330,.06,{minPitch:-18,maxPitch:6}],
  ['STI','СТ-I','ht','st-i',   2050,440,11200,258,140,250,40,1.07,370,.06,{minPitch:-16,maxPitch:8}],
  ['IS4','ИС-4','ht','is-4',   2600,440,10200,262,160,250,43,1.10,380,.05,{minPitch:-16,maxPitch:6}]
], USSR_BRANCH.slice(0,5));
const GERMAN_BRANCH = defineLine('germany', [
  ['LTR','Leichttraktor','lt','leichttraktor',      115, 35,2200, 38,14,12,30, .65,270,.33],
  ['PZII','Pz.Kpfw. II','lt','pz-ii',               165, 75,4500, 48,30,15,40, .72,285,.32,{mag:5,clipMs:130}],
  ['PZIC','Pz.Kpfw. I Ausf. C','lt','pz-i-c',       230, 96,5000, 58,30,20,68, .70,305,.34,{mag:8,clipMs:170}],
  ['LUCHS','Pz. II «Luchs»','lt','luchs',           340,180,7500, 92,30,30,60, .76,320,.34,{mag:6,clipMs:170}],
  // Primary loadouts only: Leopard's clip (lower end of 105–115), VK 28.01's 115 single shot.
  ['LEOPARD','VK 16.02 Leopard','lt','vk-16-02-leopard',500,240,9000,105,50,50,60,.84,340,.32,{mag:8,clipMs:140}],
  ['VK2801','VK 28.01','lt','vk-28-01',             680,115,3600,135,50,50,64, .93,350,.30],
  ['SPIC','Spähpanzer SP I.C.','lt','sp-i-c',       880,220,6800,175,15,15,58, .79,370,.36],
  ['HWK12','HWK 12','lt','hwk-12',                 1100,240,6800,190,15,15,65, .82,380,.34],
  ['RU251','Spähpanzer Ru 251','lt','ru-251',      1350,250,5800,210,25,20,72, .92,390,.33],
  ['RHMPZW','Rhm. Panzerwagen','lt','rheinmetall-panzerwagen',1650,320,7200,235,30,20,75,.99,405,.30]
]);
// The two heavy routes share the original Leichttraktor and one II–V progression.
const GERMAN_MAUS_BRANCH = defineLine('germany', [
  ['PZ35T','Pz.Kpfw. 35 (t)','lt','pz-35-t',        175, 45, 2300, 52, 25, 25,35, .75,300,.30,{minPitch:-20,maxPitch:10}],
  ['PZ38T','Pz.Kpfw. 38 (t)','lt','pz-38-t',        265, 60, 2600, 72, 50, 25,42, .79,310,.29,{minPitch:-20,maxPitch:10}],
  ['PZIVD','Pz.Kpfw. IV Ausf. D','mt','pz-iv-d',    390,110, 3800, 85, 30, 35,40, .90,330,.25,{minPitch:-20,maxPitch:10}],
  ['PZIVH','Pz.Kpfw. IV Ausf. H','mt','pz-iv-h',    600,125, 3700,135, 80, 50,40, .96,340,.22,{minPitch:-20,maxPitch:8}],
  ['VK3001P','VK 30.01 (P)','ht','vk-30-01-p',       920,220, 7000,145, 75, 80,50,1.10,350,.15,{minPitch:-15,maxPitch:8}],
  ['TIGERP','Tiger (P)','ht','tiger-p',             1450,240, 6600,203,200,120,35,1.12,360,.10,{minPitch:-17,maxPitch:6}],
  ['VK10001P','VK 100.01 (P)','ht','vk-100-01-p',   1850,440,12200,220,200,230,20,1.30,360,.05,{minPitch:-30,maxPitch:8}],
  ['MAUSCHEN','Mäuschen','ht','mauschen',          2300,490,12500,246,200,240,20,1.40,370,.04,{minPitch:-24,maxPitch:8}],
  ['MAUS','Maus','ht','maus',                     3000,490,11800,250,200,260,20,1.50,380,.03,{minPitch:-8,maxPitch:24}]
], GERMAN_BRANCH.slice(0,1));
const GERMAN_E100_BRANCH = defineLine('germany', [
  ['VK3601H','VK 36.01 (H)','ht','vk-36-01-h',1000,220, 6800,148,100,100,40,1.05,350,.15,{minPitch:-15,maxPitch:8}],
  ['TIGERI','Tiger I','ht','tiger-i',        1500,240, 5800,203,100,100,40,1.15,370,.10,{minPitch:-13,maxPitch:7}],
  ['TIGERII','Tiger II','ht','tiger-ii',     1650,360, 9200,225,150,185,38,1.20,380,.08,{minPitch:-15,maxPitch:7}],
  ['E75','E 75','ht','e-75',                2100,490,12500,246,160,252,38,1.30,390,.06,{minPitch:-17,maxPitch:8}],
  ['E100','E 100','ht','e-100',             2700,680,16500,246,200,250,30,1.50,400,.04,{minPitch:-20,maxPitch:7}]
], GERMAN_MAUS_BRANCH.slice(0,5));
const GERMAN_E50M_BRANCH = defineLine('germany', [
  ['VK3002M','VK 30.02 (M)','mt','vk-30-02-m', 840,135,3600,150, 60,100,55,1.00,345,.24,{minPitch:-5,maxPitch:15}],
  ['PANTHER','Panther','mt','panther',         1200,135,3200,198, 85,120,55,1.08,360,.22,{minPitch:-5,maxPitch:15}],
  ['PANTHERII','Panther II','mt','panther-ii', 1450,240,6000,223,100,120,55,1.12,370,.20,{minPitch:-5,maxPitch:15}],
  ['E50','E 50','mt','e-50',                  1750,390,8200,220,150,185,60,1.17,385,.18,{minPitch:-5,maxPitch:15}],
  ['E50M','E 50 Ausf. M','mt','e-50-ausf-m', 2050,390,7600,270,150,250,60,1.20,400,.17,{minPitch:-5,maxPitch:15}]
], GERMAN_MAUS_BRANCH.slice(0,5));
const US_BRANCH = defineLine('usa', [
  ['T1C','T1 Cunningham','lt','t1-cunningham',        120, 38,2300, 39,10, 10,32,.68,275,.32],
  ['T2MEDIUM','T2 Medium Tank','mt','t2-medium',      185, 45,2300, 50,22, 22,40,.80,285,.29],
  ['M2MEDIUM','M2 Medium Tank','mt','m2-medium',      270, 65,3000, 62,25, 25,42,.85,305,.27],
  ['M3LEE','M3 Lee','mt','m3-lee',                    400,110,3800, 92,51, 38,38,.98,320,.23,{yawLimits:[-15,15],minPitch:-9,maxPitch:20}],
  ['M4SHERMAN','M4 Sherman','mt','m4-sherman',        600,115,3500,122,51, 76,48,.98,335,.23],
  ['M4A3E8','M4A3E8 Sherman','mt','m4a3e8-sherman',   820,140,3800,142,63, 76,48,  1,345,.22],
  ['T20','T20','mt','t20',                           1080,240,6800,165,63, 89,56,.97,355,.24],
  ['PERSHING','M26 Pershing','mt','m26-pershing',    1400,240,6200,190,102,127,48,1.03,370,.21],
  ['M46PATTON','M46 Patton','mt','m46-patton',       1700,360,7600,218,102,127,48,1.04,380,.20],
  ['M48PATTON','M48 Patton','mt','m48-patton',       2050,390,7200,255,120,254,45,1.06,395,.18]
]);
// The two TD routes share the actual I–III records. A dash on the sheets
// means no separate turret armour, not zero hull armour or a discarded hit.
const US_E3_BRANCH = defineLine('usa', [
  ['T18','T18','td','t18',                        150, 75, 3600, 45, 51,null,48,.72,280,.34,{yawLimits:[-15,15],minPitch:-5,maxPitch:20}],
  ['T82','T82','td','t82',                        200,115, 4200, 95, 13,null,48,.77,300,.35,{yawLimits:[-12,12],minPitch:-5,maxPitch:27}],
  ['T40','T40','td','t40',                        315,125, 3800,128, 51,null,38,.91,315,.31,{yawLimits:[-10,15],minPitch:-10,maxPitch:30}],
  ['WOLVERINE','M10 Wolverine','td','wolverine',   480,115, 3100,128, 51,  57,48,.94,335,.30,{minPitch:-10,maxPitch:30}],
  ['JACKSON','M36 Jackson','td','jackson',         690,240, 6200,160,114,  76,42,.99,345,.28,{minPitch:-10,maxPitch:20}],
  ['T25-AT','T25 AT','td','t25-at',                940,320, 7600,198, 89,null,56,.98,350,.30,{yawLimits:[-10,10],minPitch:-10,maxPitch:20}],
  ['T28-US','T28','td','t28',                     1400,400, 8200,248,254,null,22,1.14,350,.25,{yawLimits:[-10,10],minPitch:-5,maxPitch:20}],
  ['T95','T95','td','t95',                        1900,750,15000,276,305,null,20,1.24,360,.23,{yawLimits:[-10,10],minPitch:-5,maxPitch:20}],
  ['T110E3','T110E3','td','t110e3',               2150,750,14200,295,305,null,24,1.20,370,.21,{yawLimits:[-8,8],minPitch:-8,maxPitch:16}]
], US_BRANCH.slice(0,1));
const US_E4_BRANCH = defineLine('usa', [
  ['M8A1','M8A1','td','m8a1',                      290,110, 3400,110, 29, 38,58,.80,320,.35,{minPitch:-10,maxPitch:20}],
  ['HELLCAT-V','Hellcat','td','hellcat-v',          450,115, 2900,128, 13, 25,72,.89,335,.34,{minPitch:-10,maxPitch:20}],
  ['HELLCAT','M18 Hellcat','td','hellcat',          640,240, 6400,160, 13, 76,72,.90,350,.33,{minPitch:-10,maxPitch:20}],
  ['T252','T25/2','td','t252',                      920,240, 5800,170, 76, 76,56,1.0,355,.28,{minPitch:-10,maxPitch:25}],
  ['T28-PROTOTYPE','T28 Prototype','td','t28-prototype',1300,400,8600,248,203,203,28,1.12,360,.25,{yawLimits:[-143,143],minPitch:-10,maxPitch:15}],
  ['T30','T30','td','t30',                         1750,750,16000,276,102,279,35,1.19,370,.19,{minPitch:-10,maxPitch:15}],
  ['T110E4','T110E4','td','t110e4',                2050,750,15200,295,260,203,35,1.17,375,.19,{yawLimits:[-90,90],minPitch:-6,maxPitch:12}]
], US_E3_BRANCH.slice(0,3));
// Ares shares I–VII with Patton. Each shell is fired separately from the clip;
// the cooldown in the sheet starts after the last shell, not each trigger pull.
const US_ARES_BRANCH = defineLine('usa', [
  ['ARES-75','Ares 75','mt','ares-75', 1400,448,6000,195, 80,150,50,1.02,365,.22,{mag:8,clipMs:300,weapon:'machinegun',minPitch:-7,maxPitch:45}],
  ['ARES-85','Ares 85','mt','ares-85', 1700,600,7000,210, 95,178,50,1.05,380,.21,{mag:8,clipMs:300,weapon:'machinegun',minPitch:-7,maxPitch:45}],
  ['ARES-90','Ares 90','mt','ares-90', 1950,735,8000,225,100,248,50,1.07,390,.20,{mag:7,clipMs:300,weapon:'machinegun',minPitch:-9,maxPitch:45}]
], US_BRANCH.slice(0,7));
// The T20 fork reuses I–VII of the Patton route. Store full-clip alpha,
// not per-round damage: reload is the cooldown AFTER the fourth shot.
const US_T57_BRANCH = defineLine('usa', [
  ['T69','T69','mt','t69',                   1350, 960,22000,181,102,114,51,1.02,370,.21,{mag:4,clipMs:2000,weapon:'drum',oscillating:true,minPitch:-5,maxPitch:15}],
  ['T54E1','T54E1','ht','t54e1',            1800,1560,30000,210,110,127,43,1.11,380,.14,{mag:4,clipMs:2000,weapon:'drum',oscillating:true,minPitch:-5,maxPitch:15}],
  ['T57HEAVY','T57 Heavy','ht','t57-heavy', 2250,1600,23000,258,127,152,35,1.16,395,.10,{mag:4,clipMs:2000,weapon:'drum',oscillating:true,minPitch:-5,maxPitch:15}]
], US_BRANCH.slice(0,7));
const US_T110E5_BRANCH = defineLine('usa', [
  ['T1HEAVY','T1 Heavy','ht','t1-heavy', 720,115,3600,128,102,102,35,1.05,320,.15,{minPitch:-5,maxPitch:15}],
  ['M6','M6','ht','m6',                1020,240,7200,160,102,102,35,1.10,330,.13,{minPitch:-8,maxPitch:20}],
  ['T29','T29','ht','t29',              1400,320,9000,198,102,279,35,1.14,350,.11,{minPitch:-8,maxPitch:15}],
  ['T32','T32','ht','t32',              1600,320,8200,218,127,298,35,1.13,360,.10,{minPitch:-8,maxPitch:15}],
  ['M103','M103','ht','m103',           1950,400,9500,258,127,254,34,1.18,380,.08,{minPitch:-8,maxPitch:15}],
  ['T110E5','T110E5','ht','t110e5',     2350,400,8200,258,152,254,37,1.18,395,.07,{minPitch:-10,maxPitch:20}]
], US_BRANCH.slice(0,4)); // M3 Lee → one T1 Heavy, not a second starter
const US_YOH_BRANCH = defineLine('usa', [
  ['PAWLACK','Pawlack Tank','ht','pawlack-tank',930,220,6800,155, 95,110,45,1.06,335,.14,{minPitch:-5,maxPitch:15}],
  ['MIIY','M-II-Y','ht','m-ii-y',             1320,240,6200,190,120,165,40,1.08,350,.12,{minPitch:-10,maxPitch:20}],
  ['MIIIY','M-III-Y','ht','m-iii-y',          1550,320,8200,220,135,220,40,1.10,365,.10,{minPitch:-10,maxPitch:20}],
  ['MVIY','M-VI-Y','ht','m-vi-y',             1900,400,9500,248,140,260,40,1.13,380,.09,{oscillating:true,minPitch:-10,maxPitch:20}],
  ['MVY','M-V-Y','ht','m-v-y',                2250,440,9600,258,150,280,42,1.13,395,.08,{oscillating:true,minPitch:-10,maxPitch:20}]
], US_T110E5_BRANCH.slice(0,5));
// M2 Light Tank is a new node, not the existing M2 Medium or a legacy T2 Light.
const US_SHERIDAN_BRANCH = defineLine('usa', [
  ['M2LT','M2 Light Tank','lt','m2-light-tank',              165, 40, 2100, 46,25,25,55, .72,285,.33,{minPitch:-8,maxPitch:20}],
  ['M3ST','M3 Stuart','lt','m3-stuart',                      240, 45, 2000, 56,38,38,60, .77,300,.33,{minPitch:-8,maxPitch:20}],
  ['M5ST','M5 Stuart','lt','m5-stuart',                      340, 45, 1900, 72,38,38,64, .79,320,.34,{minPitch:-8,maxPitch:20}],
  ['M24','M24 Chaffee','lt','m24-chaffee',                   500,110, 3400,108,25,38,62, .85,340,.34,{minPitch:-8,maxPitch:20}],
  ['T37','T37','lt','t37',                                   670,115, 3400,138,25,25,66, .87,350,.33,{minPitch:-10,maxPitch:20}],
  ['T71CMCD','T71 CMCD','lt','t71-cmcd',                     870,150, 3800,168,25,25,64, .86,365,.35,{minPitch:-10,maxPitch:20}],
  ['M41','M41 Walker Bulldog','lt','m41-walker-bulldog',    1100,175, 4200,185,25,25,70, .92,380,.32,{minPitch:-10,maxPitch:20}],
  ['T49','T49','lt','t49',                                  1400,560,15500,152,25,25,68, .97,390,.31,{minPitch:-10,maxPitch:20}],
  ['SHERIDAN','XM551 Sheridan','lt','xm551-sheridan',       1680,560,13500,230,20,35,65,1.04,400,.30,{minPitch:-8,maxPitch:20}]
], US_BRANCH.slice(0,1));
// The dash in the Soviet TD table means no separate turret plate. The model
// mount supplies each local traverse sector; the armoured casemate stays on the hull.
const USSR_268_BRANCH = defineLine('ussr', [
  ['AT1','АТ-1','td','at-1',                       145, 55, 2400, 62, 15,null,30, .71,275,.34,{yawLimits:[-14,14],minPitch:-5,maxPitch:15}],
  ['SU76M','СУ-76М','td','su-76m',                 205,110, 4000,100, 25,null,45, .76,300,.33,{yawLimits:[-12,12],minPitch:-4,maxPitch:25}],
  ['SU85B','СУ-85Б','td','su-85b',                 315,150, 4400,130, 25,null,45, .81,315,.32,{yawLimits:[-10,10],minPitch:-5,maxPitch:15}],
  ['SU85','СУ-85','td','su-85',                    470,180, 5200,144, 45,null,55, .89,330,.32,{yawLimits:[-10,10],minPitch:-5,maxPitch:15}],
  ['SU100','СУ-100','td','su-100',                 690,390,10500,175, 75,null,50, .97,340,.30,{yawLimits:[-10,10],minPitch:-6,maxPitch:15}],
  ['SU152','СУ-152','td','su-152',                 960,640,14500,150, 75,null,43,1.05,350,.25,{yawLimits:[-9,9],minPitch:-5,maxPitch:15}],
  ['ISU152','ИСУ-152','td','isu-152',             1200,750,15200,260, 90,null,43,1.09,360,.23,{yawLimits:[-9,9],minPitch:-5,maxPitch:15}],
  ['OBJ704','Объект 704','td','object-704',       1650,750,14000,286,120,null,37,1.14,375,.21,{yawLimits:[-10,10],minPitch:-5,maxPitch:15}],
  ['OBJ268','Объект 268','td','object-268',       1950,750,13000,303,187,null,48,1.14,390,.21,{yawLimits:[-10,10],minPitch:-5,maxPitch:15}]
], USSR_BRANCH.slice(0,1));
const USSR_MEDIUM_BRANCH = defineLine('ussr', [
  ['BT2','БТ-2','lt','bt-2',              170, 45,2300, 50, 13, 13,52,.70,300,.35,{minPitch:-8,maxPitch:25}],
  ['BT7','БТ-7','lt','bt-7',              250, 55,2400, 65, 22, 15,60,.75,320,.35,{minPitch:-8,maxPitch:25}],
  ['A20','А-20','lt','a-20',              380, 85,3200, 88, 25, 25,65,.80,340,.30,{minPitch:-7,maxPitch:25}],
  ['T34','Т-34','mt','t-34',              580,110,3400,118, 45, 45,55,.90,340,.30,{minPitch:-6,maxPitch:17}],
  ['T3485','Т-34-85','mt','t-34-85',      800,180,5200,145, 45, 90,54,1.0,350,.28,{minPitch:-7,maxPitch:22}],
  ['T43','Т-43','mt','t-43',             1100,190,4800,160, 75, 90,51,1.0,360,.25,{minPitch:-8,maxPitch:26}],
  ['T44','Т-44','mt','t-44',             1350,260,6600,195, 90,150,52,1.05,370,.25,{minPitch:-7,maxPitch:23}],
  ['T54','Т-54','mt','t-54',             1650,310,6800,220,120,200,55,1.10,390,.22,{minPitch:-5,maxPitch:20}],
  ['OBJ140','Объект 140','mt','object-140',1950,320,5800,250,100,240,55,1.10,400,.22,{minPitch:-6,maxPitch:17}]
], USSR_BRANCH.slice(0,1));
// Medium forks keep the existing owners, prices and stats of every shared node.
const USSR_430U_BRANCH = defineLine('ussr', [
  ['OBJ430','Объект 430','mt','object-430',    1750,390,8800,232,120,248,50,1.08,380,.23,{minPitch:-5,maxPitch:15}],
  ['OBJ430U','Объект 430У','mt','object-430u',2050,440,9000,252,160,300,50,1.12,395,.21,{minPitch:-5,maxPitch:15}]
], USSR_MEDIUM_BRANCH.slice(0,8)); // from T-44, not T-54
const USSR_K91_BRANCH = defineLine('ussr', [
  ['A43','А-43','mt','a-43',                 780,115,3000,135, 75, 75,55, .96,345,.27,{minPitch:-5,maxPitch:15}],
  ['A44','А-44','mt','a-44',                1100,300,8800,167, 75, 90,59,1.01,355,.25,{minPitch:-5,maxPitch:15}],
  ['OBJ416','Объект 416','mt','object-416',   1200,320,6800,201, 75,110,50, .98,365,.29,{minPitch:-5,maxPitch:15}],
  ['OBJ430II','Объект 430 II','mt','object-430-ii',1600,320,6200,219,120,248,55,1.05,380,.24,{minPitch:-5,maxPitch:15}],
  ['K91','К-91','mt','k-91',                1900,320,5200,276,140,220,55,1.07,395,.22,{minPitch:-5,maxPitch:15}]
], USSR_MEDIUM_BRANCH.slice(0,5)); // from T-34; Object 430 II is not Object 430
// The Soviet lights follow the Object 140 route through A-20 (IV), then fork at T-50.
const USSR_LIGHT_BRANCH = defineLine('ussr', [
  ['T50','Т-50','lt','t-50',            520, 75,2600,112,45, 45,55, .79,340,.34,{minPitch:-7,maxPitch:25}],
  ['MT25','МТ-25','lt','mt-25',         670, 90,2700,138,45, 45,62, .85,360,.35,{minPitch:-25,maxPitch:6}],
  ['LTG','ЛТГ','lt','lt-g',             890,180,5200,155,40,100,65, .86,370,.37,{minPitch:-25,maxPitch:5}],
  ['LTTB','ЛТТБ','lt','lttb',         1120,190,4800,178,75, 90,68, .95,380,.36,{minPitch:-15,maxPitch:8}],
  ['T54L','Т-54 обл.','lt','t-54-ltwt',1420,250,6000,200,80,160,69,1.00,390,.36,{minPitch:-17,maxPitch:5}],
  ['T100LT','Т-100 ЛТ','lt','t-100-lt',1700,300,6200,230,90,180,72,1.04,405,.40,{minPitch:-15,maxPitch:5}]
], USSR_MEDIUM_BRANCH.slice(0,4));
// null = no separate turret armour. Yaw limits are in the supplied model's local Y rotation.
const GERMAN_TD_BRANCH = defineLine('germany', [
  ['PZJAG1','Panzerjäger I','td','panzerjager-i', 145,55,2400,68,15,null,40,.70,280,.34,{yawLimits:[-10,10],minPitch:-8,maxPitch:12}],
  ['MARDER2','Marder II','td','marder-ii',         205,115,4300,105,30,null,40,.79,300,.32,{yawLimits:[-32,25],minPitch:-8,maxPitch:10}],
  ['MARDER38','Marder 38T','td','marder-38t',     310,135,4200,125,50,null,42,.81,315,.31,{yawLimits:[-28,28],minPitch:-9,maxPitch:9}],
  ['PZSFL4C','Pz.Sfl. IVc','td','pz-sfl-ivc',     460,220,6200,165,20,null,52,.92,330,.25,{yawLimits:[-5,5],minPitch:-5,maxPitch:35}],
  ['NASHORN','Nashorn','td','nashorn',            660,240,5800,203,30,null,40,1.0,340,.25,{yawLimits:[-15,15],minPitch:-8,maxPitch:20}],
  ['STEMIL','Sturer Emil','td','sturer-emil',     900,460,11200,231,50,null,25,1.05,350,.20,{yawLimits:[-5,7],minPitch:-15,maxPitch:10}],
  ['RHMBWT','Rhm.-Borsig Waffenträger','td','rhm-borsig-waffentrager',1150,490,10500,246,20,20,35,1.0,360,.30,{minPitch:-5,maxPitch:15}],
  ['WTPZ4','Waffenträger auf Pz. IV','td','waffentrager-pz-iv',1550,520,10200,276,80,20,38,1.05,380,.15,{minPitch:-5,maxPitch:45}],
  ['WTE100','Waffenträger auf E 100','td','waffentrager-e100',2000,2080,40000,276,200,20,40,1.10,395,.11,{mag:4,clipMs:2000,weapon:'drum',minPitch:-8,maxPitch:14}]
], GERMAN_BRANCH.slice(0,1));
// Waffenträger auf Pz. IV offers two independent tier Xs: the old drum or a single-shot Grille.
const GERMAN_GRILLE_BRANCH = defineLine('germany', [
  ['GRILLE15','Grille 15','td','grille-15',1800,750,14500,279,30,20,60,1.13,395,.16,{yawLimits:[-10,10],minPitch:-5,maxPitch:15}]
], GERMAN_TD_BRANCH.slice(0,9));
// Marder II is the last shared node. These casemates have no separate turret armour.
const GERMAN_JGPZE100_BRANCH = defineLine('germany', [
  ['HETZER','Hetzer','td','hetzer',                   330, 110, 3600,110, 60,null,42, .81,310,.33,{yawLimits:[-11,11],minPitch:-5,maxPitch:15}],
  ['STUG3G','StuG III Ausf. G','td','stug-iii-g',    490, 135, 3600,150, 80,null,40, .85,325,.32,{yawLimits:[-11,11],minPitch:-6,maxPitch:14}],
  ['JGPZIV','Jagdpanzer IV','td','jagdpanzer-iv',    700, 220, 5200,145, 80,null,40, .92,340,.31,{yawLimits:[-12,12],minPitch:-5,maxPitch:15}],
  ['JAGDP','Jagdpanther','td','jagdpanther',          980, 320, 7200,200, 80,null,55,1.03,350,.26,{yawLimits:[-10,10],minPitch:-5,maxPitch:15}],
  ['FERDINAND','Ferdinand','td','ferdinand',         1400, 490,11000,246,200,null,30,1.15,360,.18,{yawLimits:[-14,14],minPitch:-5,maxPitch:15}],
  ['JAGDTIGER','Jagdtiger','td','jagdtiger',         1850, 560,10500,276,250,null,38,1.19,375,.16,{yawLimits:[-10,10],minPitch:-5,maxPitch:15}],
  ['JGPZE100','Jagdpanzer E 100','td','jagdpanzer-e-100',2200,1050,22000,299,250,null,30,1.30,390,.10,{yawLimits:[-10,10],minPitch:-5,maxPitch:15}]
], GERMAN_TD_BRANCH.slice(0,3));
// German assault TDs: I–III are the existing TD records, not duplicate unlocks. The supplied
// fixed casemates follow the hull in yaw; only the separate gun pitches (no SPG top-down mode).
const GERMAN_STURMTIGER_BRANCH = defineLine('germany', [
  ['STUG3B','StuG III Ausf. B','td','stug-iii-ausf-b',    320, 140, 4500, 95, 50,null,40,.81,310,.33,{yawLimits:[0,0],minPitch:-5,maxPitch:8}],
  ['STUIG33','StuIG 33 B','td','stuig-33-b',             510, 380,11000,110, 80,null,28,.86,320,.30,{yawLimits:[0,0],minPitch:-5,maxPitch:8}],
  ['BRUMMBAER','Brummbär','td','brummbaer',               780, 480,12500,135,100,null,40,.94,330,.27,{yawLimits:[0,0],minPitch:-5,maxPitch:8}],
  ['STURMPANZER2','Sturmpanzer','td','sturmpanzer-ii',   1050, 580,14000,175,100,null,45,.97,345,.25,{yawLimits:[0,0],minPitch:-5,maxPitch:8}],
  ['STURMTIGERP','Sturmtiger (P)','td','sturmtiger-p',   1450, 740,16800,205,220,null,35,1.14,355,.18,{yawLimits:[0,0],minPitch:-5,maxPitch:8}],
  ['BAER','Bär','td','baer',                             1850, 950,20500,225,220,null,35,1.20,365,.15,{yawLimits:[0,0],minPitch:-5,maxPitch:8}],
  ['STURMTIGER','Sturmtiger','td','sturmtiger',          2050,1300,27000,240,230,null,38,1.16,375,.14,{yawLimits:[0,0],minPitch:-5,maxPitch:8}]
], GERMAN_TD_BRANCH.slice(0,3));
// Both Swedish routes start with the SAME free fm/21. Clip alpha is per-shot × 3.
const SWEDISH_BRANCH=defineLine('sweden',[
  ['STRVFM21','Strv fm/21','lt','strv-fm21',115,36,2200,38,14,14,25,.67,270,.33,{minPitch:-10,maxPitch:15}],
  ['STRVM38','Strv m/38','lt','strv-m38',170,45,2300,50,15,15,45,.72,280,.32,{minPitch:-10,maxPitch:25}],
  ['STRVM40L','Strv m/40L','lt','strv-m40l',255,50,2300,64,35,35,48,.77,305,.30,{minPitch:-15,maxPitch:25}],
  ['LAGO','Lago','mt','lago',380,75,2700,90,34,34,45,.86,320,.27,{minPitch:-10,maxPitch:25}],
  ['STRVM42','Strv m/42','mt','strv-m42',570,120,3700,115,55,55,45,.91,335,.26,{minPitch:-15,maxPitch:25}],
  ['STRV74','Strv 74','mt','strv-74',790,150,4000,148,55,55,45,.96,345,.25,{minPitch:-10,maxPitch:20}],
  ['LEO','Leo','mt','leo',1080,280,8000,168,70,70,55,1,360,.23,{minPitch:-10,maxPitch:15}],
  ['EMIL1','Emil I','ht','emil-i',1500,960,22000,215,100,180,48,1.02,355,.14,{mag:3,clipMs:3000,oscillating:true,weapon:'drum',minPitch:-10,maxPitch:15}],
  ['EMIL2','Emil II','ht','emil-ii',1850,1200,25000,242,120,230,50,1.06,375,.12,{mag:3,clipMs:3000,oscillating:true,weapon:'drum',minPitch:-9,maxPitch:10}],
  ['KRANVAGN','Kranvagn','ht','kranvagn',2200,1200,22000,252,90,280,55,1.09,395,.11,{mag:3,clipMs:2750,oscillating:true,weapon:'drum',minPitch:-9,maxPitch:10}]
]);
const SWEDISH_TD_BRANCH=defineLine('sweden',[
  ['PVLVV42','Pvlvv fm/42','td','pvlvv-fm42',145,45,2100,62,15,15,45,.69,280,.34,{yawLimits:[-30,30],minPitch:-7,maxPitch:30}],
  ['IKV72','Ikv 72','td','ikv-72',200,110,4200,88,19,null,57,.76,300,.33,{yawLimits:[-10,10],minPitch:-12,maxPitch:20}],
  ['SAV43','Sav m/43','td','sav-m43',320,140,4600,118,50,null,43,.82,315,.32,{yawLimits:[-20,15],minPitch:-14,maxPitch:20}],
  ['IKV103','Ikv 103','td','ikv-103',480,260,8000,140,19,null,48,.84,325,.34,{yawLimits:[-10,10],minPitch:-12,maxPitch:20}],
  ['IKV65','Ikv 65 Alt II','td','ikv-65-alt-ii',680,240,6200,195,25,null,60,.88,340,.33,{yawLimits:[-15,15],minPitch:-10,maxPitch:12}],
  ['IKV90','Ikv 90 Typ B','td','ikv-90-typ-b',920,260,5800,220,25,null,65,.92,355,.33,{yawLimits:[-20,20],minPitch:-10,maxPitch:12}],
  ['UDES03','UDES 03','td','udes-03',1150,390,8500,275,20,null,70,.94,365,.35,{yawLimits:[0,0],minPitch:-14,maxPitch:20,stance:'hull-gun'}],
  ['STRV1030','Strv 103-0','td','strv-103-0',1500,390,7400,295,40,null,50,1,380,.34,{yawLimits:[0,0],minPitch:-11,maxPitch:11,stance:'hull'}],
  ['STRV103B','Strv 103B','td','strv-103b',1800,390,6500,308,40,null,50,1.04,395,.33,{yawLimits:[0,0],minPitch:-11,maxPitch:11,stance:'hull'}]
],SWEDISH_BRANCH.slice(0,1));
// Hungary has its own free root. Display names/armour follow the supplied I–X sheet;
// the 44M Tas export has a fixed superstructure and a limited gun, not a moving turret.
const HUNGARIAN_BRANCH = defineLine('hungary', [
  ['V440','Straussler V-4','lt','straussler-v4-40',115, 35,2200, 38, 13, 13,35, .66,270,.33,{minPitch:-8,maxPitch:15}],
  ['TOLDI1','38M Toldi I','lt','toldi-i',          165, 80,4000, 45, 13, 13,50, .72,285,.33,{mag:4,clipMs:500,weapon:'drum',minPitch:-9,maxPitch:20}],
  ['TOLDI3','43M Toldi III','lt','toldi-iii',      250, 50,2400, 64, 35, 35,50, .76,305,.31,{minPitch:-9,maxPitch:13}],
  ['TURAN1','40M Turán I','mt','turan-i',          390, 60,2500, 85, 50, 50,47, .86,320,.27,{minPitch:-8,maxPitch:15}],
  ['TURAN2','41M Turán II','mt','turan-ii',        580,140,4400,105, 60, 60,43, .90,335,.24,{minPitch:-8,maxPitch:15}],
  ['TURAN3','43M Turán III','mt','turan-iii',      820,145,3900,145, 80, 80,43, .96,345,.23,{minPitch:-8,maxPitch:15}],
  ['TAS','44M Tas','td','tas',                    1180,220,5600,190,120,120,45,1.00,355,.28,{yawLimits:[-10,10],minPitch:-8,maxPitch:12}],
  ['T54A','T-54A','mt','t-54a',                   1380,280,6800,200,100,200,50,1.04,370,.22,{minPitch:-6,maxPitch:17}],
  ['T55A','T-55A','mt','t-55a',                   1680,320,6800,225,100,205,50,1.07,385,.22,{minPitch:-6,maxPitch:17}],
  ['T55AM1','T-55AM','mt','t-55am-1',            2000,330,5900,262,160,250,50,1.10,395,.21,{minPitch:-6,maxPitch:17}]
]);
// Japan's two routes share one Renault Otsu. Both sheets specify damage per
// single shot; STA-1 is a research vehicle, unrelated to the premium STA-2.
const JAPANESE_MEDIUM_BRANCH = defineLine('japan', [
  ['R-OTSU','Renault Otsu','lt','r-otsu',    115, 36,2200, 38, 22, 22,22, .65,270,.33,{minPitch:-22,maxPitch:20}],
  ['HA-GO','Type 95 Ha-Go','lt','ha-go',     170, 45,2300, 48, 12, 12,45, .72,285,.32,{minPitch:-15,maxPitch:20}],
  ['CHI-HA','Type 97 Chi-Ha','lt','chi-ha',  260, 60,2700, 68, 25, 25,40, .78,300,.30,{minPitch:-15,maxPitch:20}],
  ['CHI-HE','Type 1 Chi-He','mt','chi-he',   390, 75,2600, 88, 50, 50,44, .85,320,.27,{minPitch:-15,maxPitch:20}],
  ['CHI-NU','Type 3 Chi-Nu','mt','chi-nu',   570,120,3700,124, 50, 50,39, .90,335,.25,{minPitch:-10,maxPitch:15}],
  ['CHI-TO','Type 4 Chi-To','mt','chi-to',   810,155,4200,155, 75, 75,45, .96,345,.23,{minPitch:-10,maxPitch:20}],
  ['CHI-RI','Type 5 Chi-Ri','mt','chi-ri',  1200,160,3600,165, 75, 75,42,1.00,355,.22,{minPitch:-10,maxPitch:20}],
  ['STA-1','STA-1','mt','sta-1',            1350,240,5800,212, 45, 70,45,1.02,370,.22,{minPitch:-10,maxPitch:13}],
  ['TYPE-61','Type 61','mt','type-61',      1650,360,7400,245, 55,114,48,1.05,385,.21,{minPitch:-10,maxPitch:13}],
  ['STB-1','STB-1','mt','stb-1',            1950,360,6200,258,110,220,53,1.08,395,.21,{minPitch:-8,maxPitch:15}]
]);
const JAPANESE_HEAVY_BRANCH = defineLine('japan', [
  ['I-GOCHI-RO','Type 89 I-Go','mt','i-gochi-ro', 190, 65, 3500, 45, 17, 17,25, .78,280,.27,{minPitch:-15,maxPitch:20}],
  ['TYPE-91','Type 91 Heavy','ht','type-91',       320, 75, 3800, 58, 20, 20,25, .90,285,.17,{minPitch:-12,maxPitch:20}],
  ['TYPE-95','Type 95 Heavy','ht','type-95',       520,115, 4400, 88, 35, 35,22, .96,300,.16,{minPitch:-12,maxPitch:20}],
  ['MITSU-108','Mitsu 108','ht','mitsu-108',       800,240, 8200,125, 75, 75,35,1.04,310,.14,{minPitch:-10,maxPitch:20}],
  ['O-I','O-I','ht','o-i',                       1150,320, 9500,150,150,150,25,1.14,320,.09,{minPitch:-10,maxPitch:20}],
  ['O-NI','O-Ni','ht','o-ni',                    1550,350, 9800,185,175,200,25,1.16,340,.08,{minPitch:-10,maxPitch:20}],
  ['O-HO','O-Ho','ht','o-ho',                    1900,380,10200,210,200,200,25,1.17,350,.07,{minPitch:-10,maxPitch:20}],
  ['TYPE-4-H','Type 4 Heavy','ht','type-4-h',    2350,550,14500,245,250,250,20,1.20,370,.06,{minPitch:-10,maxPitch:20}],
  ['TYPE-5-H','Type 5 Heavy','ht','type-5-h',    2900,600,15000,255,260,260,25,1.22,385,.05,{minPitch:-10,maxPitch:20}]
], JAPANESE_MEDIUM_BRANCH.slice(0,1));
// French sheets: dashes in repeated rows refer to the original node. A dash *inside*
// the armour column means no separate turret plate. Clip sizes are sequential shots.
const FRENCH_TD_BRANCH = defineLine('france', [
  ['FT','Renault FT','lt','ft',                    115,35,2300,36,22,22,20, .65,270,.33,{minPitch:-10,maxPitch:35}],
  ['FT-AC','Renault FT AC','td','ft-ac',         135,45,2300,62,16,null,20, .69,280,.35,{yawLimits:[-10,10],minPitch:-7,maxPitch:15}],
  ['UE-57','Renault UE 57','td','ue-57',         185,75,3000,105,9,null,36, .68,300,.39,{yawLimits:[-7,7],minPitch:-2,maxPitch:20}],
  ['SAU-40','Somua SAu 40','td','sau-40',      320,115,4000,115,40,null,37, .85,310,.31,{yawLimits:[-7,7],minPitch:-10,maxPitch:30}],
  ['S35-CA','S35 CA','td','s35-ca',             470,240,6800,155,56,null,37, .85,320,.38,{yawLimits:[-29,15],minPitch:-9,maxPitch:22}],
  ['ARL-V39','ARL V39','td','arl-v39',          680,240,6200,185,60,null,42, .95,330,.35,{yawLimits:[-10,10],minPitch:-6,maxPitch:18}],
  ['AMX-AC-46','AMX AC mle. 46','td','amx-ac-46',950,300,7200,212,120,null,50,1.05,340,.30,{yawLimits:[-10,10],minPitch:-10,maxPitch:15}],
  ['AMX-AC-48','AMX AC mle. 48','td','amx-ac-48',1200,400,9200,248,150,null,50,1.10,350,.28,{yawLimits:[-10,10],minPitch:-6,maxPitch:18}],
  ['FOCH','AMX 50 Foch','td','foch',          1650,400,7800,257,180,null,50,1.12,370,.25,{yawLimits:[-10,10],minPitch:-6,maxPitch:18}],
  ['FOCH-155','AMX 50 Foch (155)','td','foch-155',1900,750*3,40000,293,180,null,50,1.12,380,.22,{weapon:'drum',mag:3,clipMs:5000,yawLimits:[-10,10],minPitch:-6,maxPitch:18}]
]);
const FRENCH_50B_BRANCH = defineLine('france', [
  ['D1','D1','lt','d1',                             195,45,2400,46,35,35,20, .73,285,.31,{minPitch:-18,maxPitch:20}],
  ['D2','D2','mt','d2',                             290,55,2600,62,40,46,23, .80,310,.28,{minPitch:-10,maxPitch:20}],
  ['B1','B1','ht','b1',                             460,65,2400,66,60,60,30, .95,310,.19,{minPitch:-13,maxPitch:18}],
  ['BDR-G1-B','BDR G1 B','ht','bdr-g1-b',          710,240,7800,135,60,70,30,1.00,320,.15,{minPitch:-8,maxPitch:17}],
  ['ARL-44','ARL 44','ht','arl-44',                960,240,6800,212,120,110,37,1.04,330,.12,{minPitch:-10,maxPitch:15}],
  ['AMX-M4-45','AMX M4 mle. 45','ht','amx-m4-45',1320,240,6200,212,90,100,40,1.08,350,.10,{minPitch:-10,maxPitch:12}],
  ['AMX-50-100','AMX 50 100','ht','amx-50-100',1450,300*6,38000,232,90,90,51,1.10,370,.10,{weapon:'drum',mag:6,clipMs:2500,oscillating:true,minPitch:-9,maxPitch:13}],
  ['AMX-50-120','AMX 50 120','ht','amx-50-120',1850,400*4,30000,257,100,100,65,1.13,380,.08,{weapon:'drum',mag:4,clipMs:2500,oscillating:true,minPitch:-9,maxPitch:11}],
  ['AMX-50-B','AMX 50 B','ht','amx-50-b',      2200,400*4,26000,257,170,100,65,1.15,400,.07,{weapon:'drum',mag:4,clipMs:2500,oscillating:true,minPitch:-10,maxPitch:12}]
], FRENCH_TD_BRANCH.slice(0,1));
const FRENCH_M454_BRANCH = defineLine('france', [
  ['AMX-65-T','AMX 65 t','ht','amx-65-t',          1550,300,7600,232,100,250,38,1.12,360,.09,{minPitch:-8,maxPitch:13}],
  ['AMX-M4-51','AMX M4 mle. 51','ht','amx-m4-51', 1950,400,9500,257,180,280,40,1.15,380,.07,{minPitch:-8,maxPitch:15}],
  ['AMX-M4-54','AMX M4 mle. 54','ht','amx-m4-54',2400,520,11800,255,220,300,40,1.18,390,.06,{minPitch:-8,maxPitch:15}]
], FRENCH_50B_BRANCH.slice(0,7));
const FRENCH_BATCHAT_BRANCH = defineLine('france', [
  ['H35','Hotchkiss H35','lt','h35',                 175,40,2200,45,40,40,28, .70,285,.32,{minPitch:-10,maxPitch:13}],
  ['AMX-38','AMX 38','lt','amx-38',                 270,50,2400,58,60,40,25, .75,300,.31,{minPitch:-14,maxPitch:18}],
  ['AMX-40','AMX 40','lt','amx-40',                 390,75,3000,74,70,70,35, .82,315,.30,{minPitch:-7,maxPitch:17}],
  ['AMX-ELC-BIS','AMX ELC bis','lt','amx-elc-bis', 460,220,7500,140,14,14,65, .75,360,.45,{yawLimits:[-15,15],minPitch:-5,maxPitch:13}],
  ['AMX-12-T','AMX 12 t','lt','amx-12-t',        650,135*4,14000,144,30,40,60, .80,370,.40,{weapon:'drum',mag:4,clipMs:2500,oscillating:true,minPitch:-6,maxPitch:12}],
  ['AMX-13-75','AMX 13 75','lt','amx-13-75',     870,135*4,12000,155,40,40,61, .85,380,.38,{weapon:'drum',mag:4,clipMs:2000,oscillating:true,minPitch:-6,maxPitch:9}],
  ['B-C-12-T','Bat.-Châtillon 12 t','lt','b-c-12-t',1100,170*4,15000,175,40,25,68,.90,390,.36,{weapon:'drum',mag:4,clipMs:2000,oscillating:true,minPitch:-6,maxPitch:13}],
  ['B-C-25-T-AP','Bat.-Châtillon 25 t AP','mt','b-c-25-t-ap',1600,300*6,34000,232,50,30,65,1.00,400,.28,{weapon:'drum',mag:6,clipMs:2730,oscillating:true,minPitch:-6,maxPitch:13}],
  ['B-C-25-T','Bat.-Châtillon 25 t','mt','b-c-25-t',1850,390*5,34000,259,60,50,65,1.05,410,.28,{weapon:'drum',mag:5,clipMs:2730,oscillating:true,minPitch:-6,maxPitch:11}]
], FRENCH_TD_BRANCH.slice(0,1));
// These forks reuse the existing parent records. The sheets give damage per
// projectile: a salvo fires both barrels now; a drum fires on successive inputs.
const USSR_277_BRANCH = defineLine('ussr', [
  ['T-10','Т-10','ht','t-10',                 1850,440,10800,258,120,250,50,1.07,380,.08,{minPitch:-5,maxPitch:15}],
  ['OBJ-277','Объект 277','ht','obj-277',     2200,490,11200,265,140,290,55,1.10,390,.07,{minPitch:-5.5,maxPitch:15.5}]
], USSR_BRANCH.slice(0,8));
const USSR_705A_BRANCH = defineLine('ussr', [
  ['IS-M','ИС-М','ht','is-m',                 1600,390,11200,212,130,250,35,1.08,350,.08,{minPitch:-5,maxPitch:20}],
  ['OBJ-705','Объект 705','ht','obj-705',     2000,490,12800,250,155,300,40,1.12,370,.07,{minPitch:-5,maxPitch:20}],
  ['OBJ-705A','Объект 705А','ht','obj-705a',  2450,650,15800,256,175,330,40,1.18,385,.07,{minPitch:-5,maxPitch:20}]
], USSR_BRANCH.slice(0,7));
const USSR_STII_BRANCH = defineLine('ussr', [
  ['IS-2-II','ИС-2-II','ht','is-2-ii',        1550,600,15000,221,110,220,38,1.08,350,.09,{salvo:2,minPitch:-7,maxPitch:20}],
  ['IS-3-II','ИС-3-II','ht','is-3-ii',        1900,780,19000,243,130,250,38,1.12,370,.08,{salvo:2,minPitch:-8,maxPitch:20}],
  ['ST-II','СТ-II','ht','st-ii',              2500,880,20500,258,150,250,35,1.15,385,.07,{salvo:2,minPitch:-8,maxPitch:20}]
], USSR_BRANCH.slice(0,7));
const USSR_268V4_BRANCH = defineLine('ussr', [
  ['SU-100M1','СУ-100М1','td','su-100m1',       880,250, 6200,212,120,null,54,1.00,345,.29,{yawLimits:[-8,8],minPitch:-4,maxPitch:20}],
  ['SU-101','СУ-101','td','su-101',            1200,440,10500,258,120,null,54,1.04,360,.27,{yawLimits:[-10,10],minPitch:-3,maxPitch:18.3}],
  ['OBJ-263','Объект 263','td','obj-263',      1700,550,11800,270,250,null,50,1.14,380,.22,{yawLimits:[-10,10],minPitch:-4,maxPitch:18}],
  ['OBJ-2684','Объект 268 Вариант 4','td','obj-2684',2100,650,14500,293,260,null,50,1.16,390,.21,{yawLimits:[-12,12],minPitch:-5,maxPitch:15}]
], USSR_268_BRANCH.slice(0,6));
// The tier-X 263 uses the same supplied mesh, not the tier-IX ownership ID,
// research parent, armour record or weapon stats.
const USSR_263X_BRANCH = defineLine('ussr', [
  ['SU-122-54','СУ-122-54','td','su-122-54',      1450,400,7600,258,100,null,48,1.05,370,.25,{yawLimits:[-8,8],minPitch:-4,maxPitch:16}],
  ['OBJ-263-X','Объект 263 (10 ур.)','td','obj-263',1850,460,7800,290,250,null,55,1.14,390,.21,{modelId:'OBJ-263',yawLimits:[-10,10],minPitch:-4,maxPitch:18}]
], USSR_268V4_BRANCH.slice(0,8));
const USSR_TET_BRANCH = defineLine('ussr', [
  ['KV-4F','КВ-4 Федоренко','ht','kv-4f',     1450, 750,22000,185,140,180,30,1.12,340,.08,{mag:3,clipMs:4000,weapon:'drum',minPitch:-9,maxPitch:20}],
  ['KV-4M','КВ-4 Михайлова','ht','kv-4m',     1800, 960,24000,220,220,240,25,1.18,350,.07,{mag:3,clipMs:4000,weapon:'drum',minPitch:-8,maxPitch:20}],
  ['KV-90','КВ-90','ht','kv-90',              2200,1470,33000,243,250,280,25,1.24,370,.06,{mag:3,clipMs:4000,weapon:'drum',minPitch:-8,maxPitch:20}],
  ['TET-100','ТЭТ-100','ht','tet-100',        2900,1470,31000,258,250,280,25,1.30,385,.05,{mag:3,clipMs:4000,weapon:'drum',minPitch:-8,maxPitch:30}]
], USSR_IS4_BRANCH.slice(0,6));
const GERMAN_LEOPARD1_BRANCH = defineLine('germany', [
  ['VK-3001-D','VK 30.01 (D)','mt','vk-3001-d', 790,135,3600,150,60, 80,56, .97,345,.23,{minPitch:-8,maxPitch:20}],
  ['VK-3002-D','VK 30.02 (D)','mt','vk-3002-d',1120,220,5800,145,80,120,56,1.01,355,.22,{minPitch:-8,maxPitch:20}],
  ['INDIEN-PZ','Indien-Panzer','mt','indien-pz', 1350,250,6200,212,90,130,50,1.04,370,.21,{minPitch:-10,maxPitch:20}],
  ['LEOPARD-PT-A','Leopard PT A','mt','leopard-pt-a',1600,420,8800,268,70,65,65,1.06,390,.22,{minPitch:-8,maxPitch:20}],
  ['LEOPARD-1','Leopard 1','mt','leopard-1',    1850,420,7800,278,70, 65,70,1.08,405,.21,{minPitch:-9,maxPitch:20}]
], GERMAN_MAUS_BRANCH.slice(0,5));
const GERMAN_PZVII_BRANCH = defineLine('germany', [
  ['VK-4502-A','VK 45.02 (P) Ausf. A','ht','vk-4502-a',1580,320, 8200,215,120,185,38,1.14,350,.09,{minPitch:-8,maxPitch:15}],
  ['VK-4502-B','VK 45.02 (P) Ausf. B','ht','vk-4502-b',2050,490,12600,246,200,252,30,1.20,375,.07,{minPitch:-7,maxPitch:18}],
  ['PZKPFW-VII','Pz.Kpfw. VII','ht','pzkpfw-vii',     2500,560,13500,258,200,260,33,1.25,390,.06,{minPitch:-7,maxPitch:17}]
], GERMAN_MAUS_BRANCH.slice(0,7));
const GERMAN_VK72_BRANCH = defineLine('germany', [
  ['VK-7201-K','VK 72.01 (K)','ht','vk-7201-k',2550,680,16500,250,200,260,33,1.25,390,.06,{minPitch:-7,maxPitch:17}]
], GERMAN_PZVII_BRANCH.slice(0,9));
const GERMAN_KPZ67_BRANCH = defineLine('germany', [
  ['PZ-55','Pz.Kpfw. 55','ht','pz-55',          1700,360,9500,230,135,280,40,1.12,355,.09,{minPitch:-8,maxPitch:15}],
  ['VPZ-57','Versuchspanzer 57','ht','vpz-57',   2000,390,9200,255,105,320,40,1.16,375,.08,{minPitch:-9,maxPitch:15}],
  ['KPZ-67','Kampfpanzer 67','ht','kpz-67',      2250,420,9200,270,120,340,40,1.20,395,.07,{weapon:'calibration',minPitch:-10,maxPitch:18}]
], GERMAN_E100_BRANCH.slice(0,7));
// Three research routes from soviet-german-artillery-23.zip. The supplied viewers share
// these mount stops. All use the playable SPG's single round, not the auxiliary map strike.
const SPG_MOUNT = Object.freeze({yawLimits:Object.freeze([-10,10]), minPitch:-5, maxPitch:45});
const FRENCH_13_105_BRANCH = defineLine('france', [
  ['AMX1390','AMX 13 90','lt','amx-13-90',     1320,240*4,20000,205,40,40,64,.86,395,.37,{weapon:'drum',mag:4,clipMs:2500,oscillating:true,minPitch:-6,maxPitch:13}],
  ['AMX13105','AMX 13 105','lt','amx-13-105',  1600,360*3,21000,234,50,40,68,.89,400,.36,{weapon:'drum',mag:3,clipMs:2730,oscillating:true,minPitch:-8,maxPitch:12}]
], FRENCH_BATCHAT_BRANCH.slice(0,8));
const FRENCH_EBR_BRANCH = defineLine('france', [
  ['AMD178B','Panhard AMD 178B','lt','panhard-amd-178b',     600,110,3600,125,20,26,72,.78,350,.40],
  ['HOTCHKISSEBR','Hotchkiss EBR','lt','hotchkiss-ebr',     780,175,5200,150,30,20,78,.82,355,.39],
  ['LYNX6X6','Panhard AML Lynx 6×6','lt','panhard-aml-lynx-6x6',980,240,6800,182,20,20,80,.84,360,.38],
  ['EBR90','Panhard EBR 90','lt','panhard-ebr-90',         1200,240,6200,190,40,40,85,.87,370,.38],
  ['EBR105','Panhard EBR 105','lt','panhard-ebr-105',      1450,360,9200,210,40,40,90,.90,380,.37]
], FRENCH_BATCHAT_BRANCH.slice(0,5));
const FRENCH_MURAT_BRANCH = defineLine('france', [
  ['AMX13M24','AMX 13 M24','mt','amx-13-m24',      1050,175,4600,165,40,40,58,.88,365,.29],
  ['ERAC105','ERAC 105 Proto','mt','erac-105-proto',1300,300*2,12500,205,50,70,60,.94,375,.27,{weapon:'drum',mag:2,clipMs:2500,minPitch:-8,maxPitch:15}],
  ['PROJETLOUIS','Projet Louis','mt','projet-louis',1600,350*2,13000,232,120,160,60,1,390,.24,{weapon:'drum',mag:2,clipMs:2400,oscillating:true,minPitch:-8,maxPitch:15}],
  ['PROJETMURAT','Projet Murat','mt','projet-murat',1900,390*2,12500,252,150,220,62,1.04,400,.22,{weapon:'drum',mag:2,clipMs:2000,minPitch:-8,maxPitch:15}]
], FRENCH_BATCHAT_BRANCH.slice(0,6));
const FRENCH_155_BRANCH = defineLine('france', [
  ['RENAULTFT75BS','Renault FT 75 BS','spg','renault-ft-75-bs',         120,190,13000,34,16,null,14,.65,270,.29,SPG_MOUNT],
  ['LORRAINE39LAM','Lorraine 39L AM','spg','lorraine-39l-am',          165,240,14500,38,12,null,37,.73,280,.27,SPG_MOUNT],
  ['AMX105AM47','AMX 105 AM mle. 47','spg','amx-105-am-mle-47',       220,310,17000,42,20,null,60,.79,290,.26,SPG_MOUNT],
  ['AMX13105AM50','AMX 13 105 AM mle. 50','spg','amx-13-105-am-mle-50',260,390,18500,45,20,null,60,.83,300,.26,SPG_MOUNT],
  ['AMX13F3AM','AMX 13 F3 AM','spg','amx-13-f3-am',                  320,500,22000,48,20,null,60,.87,310,.24,SPG_MOUNT],
  ['LORRAINE15550','Lorraine 155 mle. 50','spg','lorraine-155-mle-50', 370,600,25000,50,50,null,60,.99,320,.20,SPG_MOUNT],
  ['LORRAINE15551','Lorraine 155 mle. 51','spg','lorraine-155-mle-51', 420,650,26000,52,50,null,60,1.02,330,.19,SPG_MOUNT],
  ['BC15555','Bat.-Châtillon 155 55','spg','bat-chatillon-155-55',     480,680,27000,52,50,16,56,1.04,340,.18,{minPitch:-5,maxPitch:45}],
  ['BC15558','Bat.-Châtillon 155 58','spg','bat-chatillon-155-58',     540,680*3,48000,54,16,16,62,1.06,350,.17,{weapon:'drum',mag:3,clipMs:10000,minPitch:-5,maxPitch:45}]
], FRENCH_TD_BRANCH.slice(0,1));
const USSR_261_BRANCH = defineLine('ussr', [
  ['SU18','СУ-18','spg','su-18',                   120,200,14000,35,15,null,20,.65,270,.29,SPG_MOUNT],
  ['SU26','СУ-26','spg','su-26',                   170,240,15000,38,15,  15,30,.74,280,.28,SPG_MOUNT],
  ['SU5','СУ-5','spg','su-5',                      230,320,18000,42,15,null,30,.78,290,.27,SPG_MOUNT],
  ['SU122A','СУ-122А','spg','su-122a',             280,420,21000,48,15,null,30,.85,300,.26,SPG_MOUNT],
  ['SU8','СУ-8','spg','su-8',                     340,520,24000,52,20,null,48,1.05,310,.21,SPG_MOUNT],
  ['S51','С-51','spg','s-51',                     390,750,34000,56,60,null,30,1.10,320,.17,SPG_MOUNT],
  ['SU14-2','СУ-14-2','spg','su-14-2',            460,850,36000,60,60,null,30,1.27,330,.13,SPG_MOUNT],
  ['OBJ212','212А','spg','212a',                  520,900,34000,62,60,null,35,1.22,340,.14,SPG_MOUNT],
  ['OBJ261','Объект 261','spg','object-261',       580,850,26000,65,75,null,50,1.16,350,.16,SPG_MOUNT]
], USSR_BRANCH.slice(0,1));
const USSR_261V4_BRANCH = defineLine('ussr', [
  ['SU122','СУ-122','spg','su-122',                        650,420,14000,160, 45,null,46,.98,310,.23,SPG_MOUNT],
  ['SUD15','СУ-Д15','spg','su-d15',                        850,620,19000,210, 75,null,34,1.02,320,.21,SPG_MOUNT],
  ['ISU2SH','ИСУ-2Ш','spg','isu-2sh',                    1200,650,20000,255,130,null,36,1.09,330,.20,SPG_MOUNT],
  ['OBJ715G','Объект 715Г','spg','object-715g',           1350,750,22000,290,160,null,40,1.13,340,.18,SPG_MOUNT],
  ['OBJ261V4','Объект 261 Вариант 4','spg','object-261-variant-4',1500,850,24000,320,210,null,45,1.16,350,.16,SPG_MOUNT]
], USSR_261_BRANCH.slice(0,5)); // one shared СУ-122А; СУ-122 is a separate VI
const GERMAN_GWE100_BRANCH = defineLine('germany', [
  ['BISON','Sturmpanzer I Bison','spg','sturmpanzer-i-bison',120,250,17500,38, 13,null,35,.70,270,.29,SPG_MOUNT],
  ['WESPE','Wespe','spg','wespe',                          160,260,16000,38, 15,null,40,.76,280,.28,SPG_MOUNT],
  ['PZSFLIVB','Pz.Sfl. IVb','spg','pz-sfl-ivb',            220,330,18000,42, 20,  15,35,.83,290,.27,SPG_MOUNT],
  ['GRILLE-SPG','Grille','spg','grille',                   270,450,22000,48, 15,null,42,.85,300,.26,SPG_MOUNT],
  ['HUMMEL','Hummel','spg','hummel',                       340,550,24000,52, 30,null,42,1.00,310,.22,SPG_MOUNT],
  ['GWPANTHER','G.W. Panther','spg','gw-panther',           400,600,25000,54, 50,  16,46,1.05,320,.19,SPG_MOUNT],
  ['GWTIGERP','G.W. Tiger (P)','spg','gw-tiger-p',         470,850,35000,58,100,null,35,1.18,330,.15,SPG_MOUNT],
  ['GWTIGER','G.W. Tiger','spg','gw-tiger',                510,920,37000,62, 30,null,40,1.22,340,.13,SPG_MOUNT],
  ['GWE100','G.W. E 100','spg','gw-e-100',                 600,950,34000,65, 80,null,38,1.28,350,.12,SPG_MOUNT]
], GERMAN_BRANCH.slice(0,1));
function nationTree(number,title,...routes) {
  return Object.freeze({number,title,routes:Object.freeze(routes),tanks:Object.freeze([...new Set(routes.flat())])});
}
const BRANCHES = Object.freeze({
  ussr: nationTree('01','ИС-7, ИС-4, СТ-II и другие ветки СССР',
    USSR_BRANCH, USSR_277_BRANCH, USSR_705A_BRANCH, USSR_STII_BRANCH, USSR_IS4_BRANCH, USSR_TET_BRANCH,
    USSR_MEDIUM_BRANCH, USSR_430U_BRANCH, USSR_K91_BRANCH, USSR_LIGHT_BRANCH, USSR_268_BRANCH, USSR_268V4_BRANCH, USSR_263X_BRANCH,
    USSR_261_BRANCH, USSR_261V4_BRANCH),
  germany: nationTree('02','Rhm. Panzerwagen, Leopard 1, Maus и другие ветки Германии',
    GERMAN_BRANCH, GERMAN_TD_BRANCH, GERMAN_GRILLE_BRANCH, GERMAN_JGPZE100_BRANCH, GERMAN_STURMTIGER_BRANCH,
    GERMAN_MAUS_BRANCH, GERMAN_PZVII_BRANCH, GERMAN_VK72_BRANCH, GERMAN_E50M_BRANCH, GERMAN_LEOPARD1_BRANCH, GERMAN_E100_BRANCH, GERMAN_KPZ67_BRANCH,
    GERMAN_GWE100_BRANCH),
  usa: nationTree('03','M48 Patton, T110E3, T110E4, Ares 90 и другие ветки США',
    US_BRANCH, US_T57_BRANCH, US_ARES_BRANCH, US_T110E5_BRANCH, US_YOH_BRANCH, US_SHERIDAN_BRANCH,
    US_E3_BRANCH, US_E4_BRANCH),
  sweden: nationTree('04','Kranvagn и Strv 103B',SWEDISH_BRANCH,SWEDISH_TD_BRANCH),
  hungary: nationTree('05','Путь к танку: T-55AM',HUNGARIAN_BRANCH),
  japan: nationTree('06','STB-1 и Type 5 Heavy',JAPANESE_MEDIUM_BRANCH,JAPANESE_HEAVY_BRANCH),
  france: nationTree('07','Франция · восемь веток от Renault FT',
    FRENCH_TD_BRANCH, FRENCH_50B_BRANCH, FRENCH_M454_BRANCH, FRENCH_BATCHAT_BRANCH,
    FRENCH_13_105_BRANCH, FRENCH_EBR_BRANCH, FRENCH_MURAT_BRANCH, FRENCH_155_BRANCH)
});
const PLAYABLE_NATIONS = Object.freeze(Object.keys(BRANCHES));
// Specials share the same arcade visibility/scale defaults, regardless of acquisition.
function specialVehicle(spec) {
  const {cls,tier}=spec;
  return Object.freeze({s:({lt:.86,mt:1,ht:1.12,td:1.04})[cls],vr:300+8*tier,camo:({lt:.32,mt:.22,ht:.09,td:.28})[cls],...spec});
}
// National supply series. Serial numbers are the permanent keys in batch114; gaps have no verified mesh.
// Input damage below is per projectile. The catalogue stores total clip/salvo alpha; Tank uses shotDamage().
function nationalSeries(nat, source, rows) {
  return rows.map(([serial,n,cls,tier,hp,shot,reload,pen,armor,turretArmor,speed,extra={}]) => {
    const key=String(serial).padStart(3,'0'), slug='national-'+key;
    return specialVehicle({id:'NAT'+key,n,nat,source,cls,tier,hp,alpha:shot*(extra.mag||extra.salvo||1),reload,pen,armor,turretArmor,speed,
      file:slug+'.mesh.js',thumbnail:slug+'.webp',
      minPitch:-10,maxPitch:20, ...(turretArmor===null ? {yawLimits:[-10,10]} : {}), ...(source==='premium' ? {price:900*tier} : {supplyBox:'national-'+nat}), ...extra});
  });
}
const NATIONAL_TANKS = Object.freeze([
  ...nationalSeries('ussr','collection',[
    [1,'Т-60','lt',2,175,15,4200,46,35,25,44,{mag:6,clipMs:130,weapon:'machinegun'}],
    [2,'Т-70','lt',3,255,55,2400,65,35,50,45],
    [3,'БТ-СВ','lt',3,260,55,2300,62,25,20,62],
    [4,'Т-80','lt',4,370,60,2400,75,45,45,45],
    [5,'КВ-220-2','ht',5,760,115,3600,110,100,75,33],
    [6,'КВ-2','ht',6,1020,650,17500,110,75,75,35],
    [7,'СУ-100Y','td',6,750,440,12200,196,60,null,35],
    [8,'КВ-85','ht',6,950,390,12000,175,75,100,34],
    [9,'КВ-13','mt',7,1150,180,4800,155,120,100,50],
    [10,'КВ-5','ht',8,1780,300,7800,196,180,180,40],
    [11,'Объект 703 Вариант II','ht',8,1550,390,19000,221,140,220,38,{salvo:2}],
    [12,'Объект 84','lt',9,1450,280,6600,205,90,170,65],
    [13,'Объект 260','ht',10,2200,440,9200,260,150,300,60],
    [14,'Объект 907','mt',10,2000,320,5600,250,110,240,55]
  ]),
  ...nationalSeries('ussr','premium',[
    [16,'Объект 252У Защитник','ht',8,1550,440,12500,225,130,250,35],
    [17,'Т-54 первый образец','mt',8,1400,250,6500,190,120,180,44],
    [18,'СУ-130ПМ','td',8,1100,520,11200,243,20,15,65,{yawLimits:[-78,78]}],
    [19,'ЛТ-432','lt',8,1150,180,4500,176,70,160,70]
  ]),
  ...nationalSeries('germany','collection',[
    [20,'Pz.Kpfw. I','lt',2,160,12,4800,40,13,13,40,{mag:8,clipMs:130,weapon:'machinegun'}],
    [21,'Pz.Kpfw. II Ausf. G','lt',3,240,30,5600,75,30,30,55,{mag:4,clipMs:170,weapon:'machinegun'}],
    [22,'Pz.Kpfw. III Ausf. E','mt',3,255,50,2400,62,30,30,64],
    [23,'Pz.Kpfw. III Ausf. J','mt',4,390,75,2800,88,70,57,60],
    [24,'Durchbruchswagen 2','ht',4,480,75,2900,88,50,50,35],
    [25,'Pz.Kpfw. V/IV','mt',5,680,125,3700,125,85,50,55],
    [26,'Pz.Kpfw. III/IV','mt',5,580,125,3800,125,60,50,55],
    [27,'VK 30.01 (H)','ht',5,720,135,3800,150,50,80,35],
    [28,'Dicker Max','td',6,620,300,8200,169,50,null,40],
    [29,'Tiger 131','ht',6,1050,220,6400,145,100,100,40],
    [30,'E 25','td',7,880,135,2600,150,50,null,65],
    [31,'VK 168.01 (P)','ht',8,1800,440,12600,220,180,230,20],
    [32,'Kunze Panzer','mt',9,1600,390,8200,268,70,90,65],
    [33,'Kampfpanzer 50 t','mt',9,1750,320,6400,268,120,250,60],
    [34,'VK 90.01 (P)','ht',10,2600,490,11500,258,220,280,30]
  ]),
  ...nationalSeries('germany','premium',[
    [35,'Rheinmetall Skorpion','td',8,1150,490,10600,246,30,20,60],
    [36,'E 75 TS','ht',8,1600,360,9000,227,120,230,45],
    [37,'Pz.Kpfw. 58 Mutz','mt',8,1350,250,6200,212,90,120,50],
    [38,'leKpz M 41 90 mm','lt',8,1100,240,5600,182,25,25,72]
  ]),
  ...nationalSeries('usa','collection',[
    [39,'M22 Locust','lt',3,240,45,2100,56,25,25,64],
    [40,'MTLS-1G14','lt',3,250,40,3200,56,38,38,55,{barrels:2,mag:2,clipMs:350,weapon:'machinegun'}],
    [41,'T14','ht',5,720,115,3500,110,76,102,34],
    [114,'M7','lt',5,540,80,2100,110,38,51,60], // replacement for the struck US row
    [42,'M4A2E4 Sherman','mt',5,610,115,3500,115,64,76,52],
    [43,'T21','lt',6,650,115,3200,138,29,29,56],
    [44,'T78','td',6,660,240,6400,160,51,76,55],
    [45,'M56 Scorpion','td',7,820,240,5800,219,5,null,45],
    [46,'T28 Concept','td',7,1020,320,8200,198,203,null,29],
    [47,'M6A2E1','ht',8,1600,320,8600,218,191,191,29],
    [48,'Chrysler K','ht',8,1600,320,8200,212,152,254,35],
    [49,'T92E1','lt',9,1400,490,13500,210,35,40,65],
    [50,'AE Phase I','ht',9,1900,400,9200,258,127,290,35],
    [51,'Concept 1B','ht',9,1850,400,8800,258,120,280,45],
    [52,'T95E6','ht',10,2050,420,7600,258,114,210,56]
  ]),
  ...nationalSeries('usa','premium',[
    [53,'T26E4 SuperPershing','mt',8,1500,240,6200,202,140,180,40],
    [54,'M54 Renegade','ht',8,1550,360,8400,226,140,250,45],
    [55,'TS-5','td',8,1500,400,7600,248,260,null,26],
    [56,'T92','lt',8,1050,150,3600,175,25,25,60]
  ]),
  ...nationalSeries('sweden','collection',[
    [57,'Tomte L-60','lt',2,170,45,2300,48,15,15,45],
    [58,'Strv m/31','lt',3,250,50,2400,62,24,24,45],
    [59,'Lago M38','mt',3,255,50,2300,64,34,34,48],
    [61,'Strv m/42-57 Alt A.2','mt',6,780,150,15000,148,55,40,45,{mag:4,clipMs:2000,weapon:'drum'}],
    [62,'Strv 74A2','mt',6,790,150,11500,148,55,55,45,{oscillating:true,mag:3,clipMs:2000,weapon:'drum'}],
    [63,'Turbo','mt',6,800,160,4400,145,60,80,50],
    [64,'Svear','mt',7,1080,220,5600,168,75,90,52],
    [65,'Primo Victoria','mt',8,1400,240,5800,226,76,254,50],
    [66,'Stridsyxa','mt',8,1350,320,7800,210,70,120,50],
    [67,'Lätt Stridsfordon 120','td',8,1150,390,8200,272,25,null,65],
    [68,'Object Kust','td',8,1200,420,9000,265,40,null,55],
    [69,'Strv K','ht',9,1850,390,8200,252,120,254,45],
    [70,'UDES 03 Alt 3','mt',9,1600,360,22000,252,45,70,55,{mag:3,clipMs:2500,weapon:'drum'}],
    [71,'Bofors Pagod TK105','mt',9,1650,360,7400,254,60,140,52]
  ]),
  ...nationalSeries('sweden','premium',[
    [72,'Lansen C','mt',8,1350,320,7600,208,60,70,50],
    [73,'Strv 81','mt',8,1400,240,5800,226,76,254,50],
    [74,'EMIL 1951','ht',8,1450,320,22000,217,100,180,45,{oscillating:true,mag:3,clipMs:2750,weapon:'drum'}],
    [75,'Bofors Tornvagn','ht',8,1600,400,10600,248,200,280,32]
  ]),
  ...nationalSeries('japan','collection',[
    [76,'Type 97 Te-Ke','lt',2,165,45,2300,45,12,12,42],
    [77,'Chi-Ni','mt',2,180,60,3200,44,25,25,30],
    [78,'Type 98 Ke-Ni','lt',3,250,45,2000,58,16,16,50],
    [79,'Type 98 Ke-Ni Otsu','lt',3,255,45,1800,58,16,16,50],
    [80,'Type 5 Ke-Ho','lt',4,370,75,2400,88,20,20,50],
    [81,'O-I Experimental','ht',5,820,240,8200,125,75,75,35],
    [83,'Edelweiss','mt',8,1380,240,5600,212,90,120,58],
    [84,'Nameless','ht',8,1600,320,8200,215,160,200,40],
    [85,'Chi-Se','ht',8,1620,320,7600,220,140,220,40],
    [86,'Stitch','ht',8,1600,320,7800,220,140,220,40],
    [88,'Kame','mt',9,1650,360,7200,245,80,150,50],
    [89,'Saryuda','td',9,1500,520,10500,278,120,null,45],
    [90,'Ashigaru','td',10,1850,600,11200,305,150,null,45]
  ]),
  ...nationalSeries('japan','premium',[
    [91,'Type 3 Chi-Nu Kai','mt',5,600,125,3800,124,50,75,39],
    [92,'Heavy Tank No. VI','ht',6,1020,220,6400,145,100,100,40],
    [93,'Type 63','ht',8,1550,320,7800,225,120,260,42,{oscillating:true}],
    [94,'Type 5 Ka-Ri','td',8,1250,500,10800,252,190,null,40]
  ]),
  ...nationalSeries('france','collection',[
    [95,'AM Gendron','lt',2,160,40,2100,46,15,15,60],
    [96,'AMR 35','lt',2,165,40,2200,46,13,13,55],
    [97,'Renault R35','lt',2,185,40,2300,46,40,40,23],
    [98,'FCM 36','lt',2,180,40,2300,46,40,40,24],
    [99,'FCM 36 Pak 40','td',3,195,110,3800,98,40,null,24],
    [100,'AMX 13 FL 11','lt',5,480,110,3200,110,40,40,60],
    [101,'M10 RBFM','td',5,480,115,3100,128,51,57,48],
    [102,'AMX 13 57','lt',7,880,90,15000,143,40,40,61,{oscillating:true,mag:8,clipMs:1000,weapon:'drum'}],
    [103,'Panhard EBR 75 (FL 10)','lt',8,950,175,8200,180,40,40,80,{oscillating:true,mag:2,clipMs:1500,weapon:'drum'}],
    [104,'FCM 50 t','ht',8,1500,240,6000,212,120,120,51],
    [105,'AMX Chasseur de chars','mt',8,1350,240,5800,212,30,30,57],
    [106,'Lorraine 40 t','mt',8,1300,300,26000,232,40,45,60,{oscillating:true,mag:4,clipMs:2500,weapon:'drum'}],
    [107,'Char Futur 4','mt',9,1750,390,32000,264,90,110,60,{mag:4,clipMs:4000,weapon:'drum'}],
    [108,'AMX 30 1er prototype','mt',9,1650,390,8200,248,80,150,65],
    [109,'AMX 30 B','mt',10,1900,390,7000,248,80,150,65]
  ]),
  ...nationalSeries('france','premium',[
    [110,'ELC EVEN 90','lt',8,950,220,22000,175,15,15,70,{oscillating:true,mag:3,clipMs:2500,weapon:'drum'}],
    [111,'Bat.-Châtillon Bourrasque','mt',8,1250,360,18000,190,40,40,62,{mag:2,clipMs:2000,weapon:'drum'}],
    [112,'Somua SM','ht',8,1450,300,30000,232,140,120,37,{oscillating:true,mag:5,clipMs:2250,weapon:'drum'}],
    [113,"AMX Canon d'assaut 105",'td',8,1150,390,8400,260,100,null,55]
  ])
]);
// Special vehicles have a real tier, but no XP price or research parent.
// The category determines the garage label and resale currency, not the contents of a seasonal box.
const SPECIAL_TANKS = Object.freeze([
  // source, ID, name, nation, tier, class, slug, HP, full load, reload ms, pen, hull, turret, km/h, model limits
  ['collection','PZ-II-J','Pz.Kpfw. II Ausf. J','germany',3,'lt','pz-ii-j',290,75,4200,46,80,80,31,{mag:5,clipMs:130,minPitch:-20,maxPitch:10}],
  ['collection','T67','T67','usa',5,'td','t67',440,115,2800,128,13,25,67,{minPitch:-20,maxPitch:10}],
  ['collection','GPZ','G.Pz. Mk. VI (e)','germany',2,'spg','gpz-mk-vi-e',125,220,14500,35,22,null,50,{s:.70,vr:270,camo:.29,yawLimits:[-5,5],minPitch:-3,maxPitch:42}],
  ['collection','M4A3E2','M4A3E2 Sherman Jumbo','usa',6,'mt','m4a3e2-sherman-jumbo',880,140,4000,138,102,152,35,{minPitch:-25,maxPitch:10}],
  ['collection','T71DA','T71 DA','usa',7,'lt','t71-da',860,900,20000,175,25,25,64,{mag:6,clipMs:2000,weapon:'drum',oscillating:true,minPitch:-20,maxPitch:7}],
  ['collection','JPANTHERII','Jagdpanther II','germany',8,'td','jagdpanther-ii',1200,490,10800,246,100,null,55,{yawLimits:[-10,10],minPitch:-15,maxPitch:6.5}],
  ['collection','T62A','Т-62А','ussr',10,'mt','t-62a',1950,320,5600,255,102,240,50,{minPitch:-17,maxPitch:6}],
  ['collection','TL7','TL-7','usa',9,'td','tl-7',1500,1440,32000,252,100,200,50,{mag:4,clipMs:2300,weapon:'drum',minPitch:-10,maxPitch:15}],
  ['premium','IS6','ИС-6','ussr',8,'ht','is-6',1550,390,10800,196,100,150,35,{price:7000,minPitch:-20,maxPitch:6}],
  ['premium','LOWE','Löwe','germany',8,'ht','lowe',1650,320,9200,234,150,120,35,{price:8000,minPitch:-17,maxPitch:8}],
  ['premium','T34HEAVY','T34','usa',8,'ht','t34-heavy',1550,400,12200,248,102,279,35,{price:7600,minPitch:-15,maxPitch:10}],
  ['premium','STA2','STA-2','japan',8,'mt','sta-2',1380,240,5700,212,45,70,55,{price:6100,minPitch:-10,maxPitch:13}],
  ['premium','STRVS1','Strv S1','sweden',8,'td','strv-s1',1100,390,8800,288,30,null,50,{price:6500,stance:'hull',yawLimits:[0,0],minPitch:-11,maxPitch:11}],
  ['advent','BT42','БТ-42','finland',4,'lt','bt-42',370,210,7500,75,22,15,54,{minPitch:-5,maxPitch:15}],
  ['advent','TL7OLEN','TL-7 Олень','usa',9,'td','tl-7-olen',1500,1440,32000,252,100,200,50,{mag:4,clipMs:2300,weapon:'drum',minPitch:-10,maxPitch:15}]
].map(([source,id,n,nat,tier,cls,slug,hp,alpha,reload,pen,armor,turretArmor,speed,extra]) => specialVehicle({
  source,id,n,nat,tier,cls,file:slug+'.mesh.js',thumbnail:slug+'.webp',hp,alpha,reload,pen,armor,turretArmor,speed,
  ...extra
})).concat(NATIONAL_TANKS));
const DB = Object.freeze(Object.fromEntries([...Object.values(BRANCHES).flatMap(b=>b.tanks),...SPECIAL_TANKS].map(t=>[t.id,t])));
const TRAINING_NATIONS = Object.freeze([...new Set(Object.values(DB).map(t=>t.nat))]);
const STARTER_TANK = 'MS1';
const modelKey = id => DB[id].modelId || id;
const shotDamage = t => t.alpha / (t.salvo || t.mag || 1);
const magazineName = t => t.weapon === 'machinegun' || t.weapon === 'drum' ? 'Барабан' : 'Кассета';
const damageLabel = t => t.salvo ? 'Урон залпа' : !t.mag ? 'Урон за выстрел' : magazineName(t) === 'Барабан' ? 'Урон барабана' : 'Урон кассеты';
const damageSummary = t => (t.salvo || t.mag) ? `${t.alpha} (${t.salvo || t.mag} × ${shotDamage(t)})` : String(t.alpha);
const clipLabel = t => (t.clipMs/1000).toLocaleString('ru-RU')+' с';
const reloadLabel = t => t.salvo ? 'Перезарядка залпа' : t.mag ? 'Полная перезарядка' : 'Перезарядка';
const armorLabel = t => `${t.armor}${t.markedHull ? '*' : ''} / ${t.turretArmor ?? '—'}${t.markedTurret ? '*' : ''}`;
const speedLabel = t => t.roadSpeed ? `${t.speed}–${t.roadSpeed}` : String(t.speed);
const researchParent = id => DB[id].parent;
